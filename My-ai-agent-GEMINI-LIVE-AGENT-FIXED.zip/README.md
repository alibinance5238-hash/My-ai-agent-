# My AI Agent — Gemini Live Android Agent

This source is updated for the current Gemini 3.8 Live API.

## What this build is designed to do

- Real-time two-way voice with Gemini 3.8 Live.
- Native Gemini audio response played through the phone speaker.
- Server VAD so the user can interrupt the agent; queued audio is cleared when Gemini reports an interruption.
- Background microphone foreground service so voice can continue after leaving the app.
- Roman Urdu + English understanding, with simple Roman Urdu spoken replies by default.
- Gemini Live function calling for opening apps/websites, reading the current accessibility screen, clicking visible controls, filling ordinary form fields, scrolling, Back, and Home.
- One-shot microphone button also speaks the text-model reply using Android TTS.
- Accessibility service blocks passwords, OTPs, PINs, CVV/card numbers, verification codes, and similar security fields.

## Gemini model

- Typed requests: `gemini-3.8-flash`
- Live voice: `gemini-3.8-live`

## API key

Create a Gemini API key in Google AI Studio and paste it into the app. Do not commit the key into GitHub.

The Live API uses the Gemini WebSocket endpoint with the API key as the `key` query parameter. The source does not contain a hard-coded key.

## Required Android setup

1. Allow microphone permission.
2. Tap **ENABLE SCREEN CONTROL** and enable the Agent Accessibility service if you want the agent to click/fill/scroll other apps.
3. Tap **START BACKGROUND VOICE**. Wait for **Live voice ON** before speaking.
4. Screen Share is optional. Accessibility screen inspection is used first for structured UI actions.
5. Notification access is optional and is only needed for notification-related features.

## Important limitation

Android security and app-specific UI rules mean no third-party assistant can safely guarantee literally every action in every app. This build supports the common safe actions exposed through Android Accessibility. Passwords, OTPs, PINs, payment authorization and similar security checkpoints are intentionally blocked.

## Security

For a production app, use Gemini ephemeral tokens or a server-side broker instead of keeping a long-lived Gemini API key on the phone. This build keeps the key locally because it is a simple client-only project.
