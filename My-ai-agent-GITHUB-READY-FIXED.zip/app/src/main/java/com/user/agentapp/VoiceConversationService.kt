package com.user.agentapp

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import android.content.pm.ServiceInfo
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.cancel
import java.util.Locale

/**
 * Keeps a conversational voice loop alive while Agent is outside its Activity.
 * It uses Android's SpeechRecognizer without ACTION_RECOGNIZE_SPEECH, so the
 * large Google voice popup is not shown. The foreground-service notification
 * is required by Android while microphone capture continues in the background.
 *
 * Barge-in: when speech arrives while TTS is speaking, TTS is stopped and the
 * new utterance is processed.
 */
class VoiceConversationService : Service(), RecognitionListener, TextToSpeech.OnInitListener {
    companion object {
        const val ACTION_START = "com.user.agentapp.START_VOICE"
        const val ACTION_STOP = "com.user.agentapp.STOP_VOICE"
        const val CHANNEL_ID = "agent_voice"
        const val NOTIFICATION_ID = 3001
        const val EXTRA_STATUS = "voice_status"

        var running = false
            private set
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var restarting = false

    override fun onCreate() {
        super.onCreate()
        createChannel()
        tts = TextToSpeech(this, this)
        ServiceCompat.startForeground(this, NOTIFICATION_ID, buildNotification("Agent live voice ON"), ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopSelf()
            ACTION_START, null -> startListeningSoon()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        recognizer?.cancel()
        recognizer?.destroy()
        recognizer = null
        tts?.stop()
        tts?.shutdown()
        tts = null
        serviceScope.coroutineContext.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun startListeningSoon() {
        if (running) return
        running = true
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            stopSelf()
            return
        }
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(this)
        startListening()
    }

    private fun startListening() {
        if (!running || restarting) return
        restarting = true
        try {
            recognizer?.cancel()
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            }
            recognizer?.startListening(intent)
        } finally {
            restarting = false
        }
    }

    override fun onReadyForSpeech(params: Bundle?) {}
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(rmsdB: Float) {}
    override fun onBufferReceived(buffer: ByteArray?) {}
    override fun onEvent(eventType: Int, params: Bundle?) {}
    override fun onEndOfSpeech() {}

    override fun onPartialResults(partialResults: Bundle?) {
        val text = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            ?.firstOrNull().orEmpty().trim()
        // Stop spoken output as soon as the user begins a new turn.
        if (text.isNotBlank()) tts?.stop()
    }

    override fun onResults(results: Bundle?) {
        val spoken = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            ?.firstOrNull().orEmpty().trim()
        if (spoken.isNotBlank()) handleSpeech(spoken)
        startListening()
    }

    override fun onError(error: Int) {
        if (!running) return
        // SpeechRecognizer can end after silence/network hiccups. Restart it.
        startListening()
    }

    private fun handleSpeech(spoken: String) {
        sendStatus("Aap: $spoken")
        serviceScope.launch {
            val screen = ScreenShareService.latestJpeg
            val reply = withContext(Dispatchers.IO) {
                GeminiClient.ask(this@VoiceConversationService, spoken, screen)
            }
            sendStatus("Agent: $reply")
            CommandExecutor.tryExecuteScreenAction(this@VoiceConversationService, reply)
            speak(reply)
        }
    }

    private fun speak(text: String) {
        if (!ttsReady) return
        tts?.stop()
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "agent_reply")
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        if (ttsReady) {
            tts?.language = Locale.getDefault()
        }
    }

    private fun sendStatus(text: String) {
        val intent = Intent("com.user.agentapp.VOICE_STATUS").apply {
            setPackage(packageName)
            putExtra(EXTRA_STATUS, text)
        }
        sendBroadcast(intent)
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Agent live voice", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun buildNotification(text: String): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Agent")
            .setContentText(text)
            .setOngoing(true)
            .build()
}
