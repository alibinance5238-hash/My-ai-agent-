package com.user.agentapp

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import android.os.Build
import android.os.IBinder
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import android.content.pm.ServiceInfo
import androidx.core.content.ContextCompat
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * True background, full-duplex Gemini Live voice service.
 *
 * Mic: 16 kHz mono PCM16 -> Gemini Live WebSocket.
 * Gemini: native 24 kHz PCM16 -> AudioTrack.
 * Server VAD handles natural turn-taking; an interrupted server message
 * immediately flushes playback so the user can barge in while Agent speaks.
 */
class VoiceConversationService : Service() {
    companion object {
        const val ACTION_START = "com.user.agentapp.START_VOICE"
        const val ACTION_STOP = "com.user.agentapp.STOP_VOICE"
        const val CHANNEL_ID = "agent_voice"
        const val NOTIFICATION_ID = 3001
        const val EXTRA_STATUS = "voice_status"
        private const val TAG = "AgentLiveVoice"
        private const val MODEL = "gemini-3.8-live"
        private const val INPUT_RATE = 16_000
        private const val OUTPUT_RATE = 24_000

        @Volatile var running = false
            private set
    }

    private val liveClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .writeTimeout(20, TimeUnit.SECONDS)
        .build()

    private val active = AtomicBoolean(false)
    private var socket: WebSocket? = null
    private var recorder: AudioRecord? = null
    private var recorderThread: Thread? = null
    private var audioTrack: AudioTrack? = null
    private var echoCanceler: AcousticEchoCanceler? = null
    private var noiseSuppressor: NoiseSuppressor? = null
    private var startedForeground = false
    private val mainHandler = Handler(Looper.getMainLooper())

    override fun onCreate() {
        super.onCreate()
        createChannel()
        ServiceCompat.startForeground(
            this,
            NOTIFICATION_ID,
            buildNotification("Live Voice ON — Gemini sun raha hai"),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        )
        startedForeground = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopVoice()
            ACTION_START, null -> startVoice()
        }
        return START_NOT_STICKY
    }

    private fun startVoice() {
        if (active.get()) return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            sendStatus("Mic permission ON nahi hai.")
            stopSelf()
            return
        }
        if (!GeminiClient.hasApiKey(this)) {
            sendStatus("Gemini API key save nahi hai.")
            stopSelf()
            return
        }

        active.set(true)
        running = true
        sendStatus("Gemini Live connect ho raha hai...")
        connectLive()
    }

    private fun connectLive() {
        val key = GeminiClient.getSavedApiKey(this)
        val url = "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key=$key"
        val request = Request.Builder().url(url).build()

        socket?.cancel()
        socket = liveClient.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                if (!active.get()) return
                sendSetup(webSocket)
                startAudioCapture()
                sendStatus("Live voice ON — ab seedha baat karo.")
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                handleServerMessage(webSocket, text)
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                if (socket === webSocket) socket = null
                Log.e(TAG, "WebSocket failure", t)
                sendStatus("Gemini Live connection error: ${t.message ?: "unknown error"}")
                if (active.get()) {
                    stopAudioCapture()
                    handlerRestart()
                }
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                if (socket === webSocket) socket = null
                if (active.get()) {
                    sendStatus("Gemini Live disconnect hua: $reason")
                    stopAudioCapture()
                    handlerRestart()
                }
            }
        })
    }

    private fun sendSetup(ws: WebSocket) {
        val tools = JSONArray().put(
            JSONObject().put("functionDeclarations", JSONArray().apply {
                put(functionDeclaration("open_app", "Open an installed Android app by its visible/common name.", mapOf("app" to "string"), listOf("app")))
                put(functionDeclaration("open_url", "Open a website URL in the Android browser.", mapOf("url" to "string"), listOf("url")))
                put(functionDeclaration("inspect_screen", "Read the current Android accessibility screen before choosing a field or button."))
                put(functionDeclaration("click_button", "Click a visible non-sensitive button or link by its text.", mapOf("text" to "string"), listOf("text")))
                put(functionDeclaration("fill_field", "Fill a visible non-sensitive form field. Never use for passwords, OTPs, PINs, CVV, card numbers, or verification codes.", mapOf("field" to "string", "value" to "string"), listOf("field", "value")))
                put(functionDeclaration("type_focused_field", "Type into the currently focused non-sensitive field.", mapOf("value" to "string"), listOf("value")))
                put(functionDeclaration("go_back", "Go back one Android screen."))
            })
        )

        val setup = JSONObject().put("setup", JSONObject().apply {
            put("model", "models/$MODEL")
            put("responseModalities", JSONArray().put("AUDIO"))
            put("inputAudioTranscription", JSONObject().put("mode", "SMART"))
            put("outputAudioTranscription", JSONObject())
            put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM_PROMPT))))
            put("tools", tools)
            put("contextWindowCompression", JSONObject().put("triggerTokens", 25_000).put("slidingWindow", JSONObject().put("targetTokens", 8_000)))
        })
        ws.send(setup.toString())
    }

    private fun functionDeclaration(
        name: String,
        description: String,
        fields: Map<String, String> = emptyMap(),
        required: List<String> = emptyList()
    ): JSONObject = JSONObject().apply {
        put("name", name)
        put("description", description)
        if (fields.isNotEmpty()) {
            put("parameters", JSONObject().apply {
                put("type", "OBJECT")
                put("properties", JSONObject().apply {
                    fields.forEach { (key, type) -> put(key, JSONObject().put("type", type.uppercase()).put("description", key)) }
                })
                put("required", JSONArray(required))
            })
        }
    }

    private fun handleServerMessage(ws: WebSocket, raw: String) {
        try {
            val json = JSONObject(raw)
            if (json.has("setupComplete")) {
                sendStatus("Gemini Live ready — sun raha hoon.")
                return
            }

            json.optJSONObject("toolCall")?.let { toolCall ->
                handleToolCall(ws, toolCall)
            }

            val content = json.optJSONObject("serverContent") ?: return

            content.optJSONObject("inputTranscription")?.optString("text")?.takeIf { it.isNotBlank() }?.let {
                sendStatus("Aap: $it")
            }
            content.optJSONObject("interimInputTranscription")?.optString("text")?.takeIf { it.isNotBlank() }?.let {
                sendStatus("Sun raha hoon: $it")
            }
            content.optJSONObject("outputTranscription")?.optString("text")?.takeIf { it.isNotBlank() }?.let {
                sendStatus("Agent: $it")
            }

            if (content.optBoolean("interrupted", false)) {
                flushPlayback()
                sendStatus("Aap bol rahe hain — Agent chup.")
            }

            val modelTurn = content.optJSONObject("modelTurn") ?: return
            val parts = modelTurn.optJSONArray("parts") ?: return
            for (i in 0 until parts.length()) {
                val part = parts.optJSONObject(i) ?: continue
                val inline = part.optJSONObject("inlineData") ?: part.optJSONObject("inline_data") ?: continue
                val mime = inline.optString("mimeType", inline.optString("mime_type", ""))
                val data = inline.optString("data", "")
                if (data.isNotBlank() && mime.startsWith("audio/pcm")) {
                    val pcm = Base64.decode(data, Base64.NO_WRAP)
                    playPcm(pcm)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Bad Live message", e)
        }
    }

    private fun handleToolCall(ws: WebSocket, toolCall: JSONObject) {
        val calls = toolCall.optJSONArray("functionCalls") ?: return
        val responses = JSONArray()
        for (i in 0 until calls.length()) {
            val call = calls.optJSONObject(i) ?: continue
            val id = call.optString("id")
            val name = call.optString("name")
            val args = call.optJSONObject("args") ?: JSONObject()
            val result = CommandExecutor.executeLiveTool(this, name, args)
            sendStatus("Agent: ${result.optString("result")}")
            responses.put(
                JSONObject()
                    .put("id", id)
                    .put("name", name)
                    .put("response", JSONObject().put("result", result))
            )
        }
        ws.send(JSONObject().put("toolResponse", JSONObject().put("functionResponses", responses)).toString())
    }

    private fun startAudioCapture() {
        if (recorder != null) return
        val min = AudioRecord.getMinBufferSize(
            INPUT_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        val bufferSize = (min * 2).coerceAtLeast(INPUT_RATE / 5 * 2)
        val r = AudioRecord(
            MediaRecorder.AudioSource.VOICE_COMMUNICATION,
            INPUT_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
            bufferSize
        )
        if (r.state != AudioRecord.STATE_INITIALIZED) {
            r.release()
            sendStatus("Mic initialize nahi hua.")
            return
        }
        recorder = r
        try {
            if (AcousticEchoCanceler.isAvailable()) {
                echoCanceler = AcousticEchoCanceler.create(r.audioSessionId)?.apply { enabled = true }
            }
            if (NoiseSuppressor.isAvailable()) {
                noiseSuppressor = NoiseSuppressor.create(r.audioSessionId)?.apply { enabled = true }
            }
        } catch (_: Exception) {}

        r.startRecording()
        recorderThread = Thread({
            val chunk = ByteArray(INPUT_RATE / 25 * 2) // ~40ms
            while (active.get() && recorder === r) {
                val n = r.read(chunk, 0, chunk.size, AudioRecord.READ_BLOCKING)
                if (n > 0) {
                    val ws = socket
                    if (ws != null) {
                        val audio = Base64.encodeToString(chunk, 0, n, Base64.NO_WRAP)
                        val msg = JSONObject().put("realtimeInput", JSONObject().put("audio", JSONObject().put("data", audio).put("mimeType", "audio/pcm;rate=16000")))
                        ws.send(msg.toString())
                    }
                }
            }
        }, "AgentMic")
        recorderThread?.start()
    }

    private fun stopAudioCapture() {
        val r = recorder
        recorder = null
        try { r?.stop() } catch (_: Exception) {}
        try { r?.release() } catch (_: Exception) {}
        recorderThread = null
        try { echoCanceler?.release() } catch (_: Exception) {}
        try { noiseSuppressor?.release() } catch (_: Exception) {}
        echoCanceler = null
        noiseSuppressor = null
    }

    private fun ensureAudioTrack(): AudioTrack? {
        if (audioTrack != null) return audioTrack
        val min = AudioTrack.getMinBufferSize(
            OUTPUT_RATE,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        val buffer = min.coerceAtLeast(OUTPUT_RATE / 5 * 2)
        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(OUTPUT_RATE)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(buffer)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        track.play()
        audioTrack = track
        return track
    }

    private fun playPcm(data: ByteArray) {
        try {
            ensureAudioTrack()?.write(data, 0, data.size, AudioTrack.WRITE_BLOCKING)
        } catch (e: Exception) {
            Log.e(TAG, "Audio playback failed", e)
        }
    }

    private fun flushPlayback() {
        try {
            audioTrack?.pause()
            audioTrack?.flush()
            if (active.get()) audioTrack?.play()
        } catch (_: Exception) {}
    }

    private fun stopVoice() {
        active.set(false)
        running = false
        stopAudioCapture()
        flushPlayback()
        try { audioTrack?.stop() } catch (_: Exception) {}
        try { audioTrack?.release() } catch (_: Exception) {}
        audioTrack = null
        socket?.close(1000, "User stopped voice")
        socket = null
        sendStatus("Live Voice OFF.")
        stopSelf()
    }

    private fun handlerRestart() {
        if (!active.get()) return
        mainHandler.postDelayed({
            if (active.get() && socket == null) connectLive()
        }, 900)
    }

    override fun onDestroy() {
        active.set(false)
        running = false
        stopAudioCapture()
        try { audioTrack?.stop() } catch (_: Exception) {}
        try { audioTrack?.release() } catch (_: Exception) {}
        audioTrack = null
        try { socket?.close(1000, "Service destroyed") } catch (_: Exception) {}
        socket = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun sendStatus(text: String) {
        val intent = Intent("com.user.agentapp.VOICE_STATUS").apply {
            setPackage(packageName)
            putExtra(EXTRA_STATUS, text)
        }
        sendBroadcast(intent)
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Agent live voice", NotificationManager.IMPORTANCE_LOW).apply {
                    setSound(null, null)
                    enableVibration(false)
                }
            )
        }
    }

    private fun buildNotification(text: String): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Agent")
            .setContentText(text)
            .setOngoing(true)
            .setSilent(true)
            .build()

    private val SYSTEM_PROMPT = """
You are Agent, a natural Android assistant for a Pakistani user.

Speak naturally in simple Roman Urdu unless the user is clearly speaking English. Never use Hindi/Devanagari script.
Listen continuously. The user may interrupt you at any time. If the user starts speaking while you are answering, stop your spoken response and focus on the user's new request.

You can perform safe Android actions through the declared tools. Use tools instead of merely saying you will do an action.
For opening an app: call open_app. For a website: call open_url.
For form filling or clicking, first call inspect_screen so you know the current visible UI. Only fill ordinary non-sensitive fields.
Never handle passwords, OTPs, PINs, CVV, card numbers, verification codes, payment authorization, or security checkpoints. Ask the user to take over for those.
If a request is ambiguous, ask a short clarification instead of guessing.
After a tool succeeds, briefly tell the user what happened. Do not claim success before the tool result.
""".trimIndent()
}
