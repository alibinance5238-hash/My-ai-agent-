# My AI Agent — Gemini Live Voice build

This build uses:

- **Gemini 3.8 Flash** for typed/text requests.
- **Gemini 3.8 Live** for real-time background voice.
- Android `AudioRecord` at 16 kHz PCM input.
- Gemini Live native audio output at 24 kHz PCM.
- Gemini server-side voice activity detection for natural turn-taking and interruption.
- `AudioTrack` playback with Android acoustic echo cancellation/noise suppression when available.
- Gemini Live function calling for safe app opening, URL opening, screen inspection, button clicks, ordinary form filling, focused-field typing, and Back.
- Existing Accessibility service remains the Android UI execution layer.

## API key
Create a Gemini API key in Google AI Studio and paste it into the app. Do not commit the key into GitHub.

## Required Android permissions/settings

1. Allow microphone permission.
2. Enable **Screen Control / Accessibility** if the agent must click or fill fields.
3. Enable **Notification access** only if notification features are needed.
4. Start **Background Voice**. The app can then be minimized while the foreground microphone service keeps the Live session active.
5. Screen Share is only needed when the agent needs an image of the screen; Accessibility `inspect_screen` is preferred for structured UI understanding.

## Important security note
The app stores the API key locally in SharedPreferences because this is a simple client-only build. For a production app, use Gemini ephemeral tokens/server-side authentication instead of putting a long-lived API key on the device.
