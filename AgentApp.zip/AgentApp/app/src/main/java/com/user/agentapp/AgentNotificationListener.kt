package com.user.agentapp

import android.app.Notification
import android.app.RemoteInput
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log

/**
 * Reads incoming notifications (WhatsApp, Instagram DMs, etc) so Agent can
 * tell you what came in, and can send a reply THROUGH the notification's own
 * "quick reply" action — the same mechanism smartwatches and Android Auto
 * use. This does not log into WhatsApp or touch its data directly; it only
 * uses the reply button WhatsApp itself puts on the notification.
 *
 * User must manually enable this once in:
 * Settings > Apps > Special access > Notification access > Agent
 * (Android requires this to be a manual, visible permission — no app can
 * turn it on for itself.)
 */
class AgentNotificationListener : NotificationListenerService() {

    companion object {
        const val TAG = "AgentNotifListener"
        // MainActivity reads this to show "Agent: Aapko WhatsApp pe message aaya..."
        var lastNotification: NotificationData? = null
        var listener: ((NotificationData) -> Unit)? = null
        // The running service instance — Android creates/binds this, so
        // MainActivity must use this reference, not "new" a fresh one.
        var runningInstance: AgentNotificationListener? = null
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        runningInstance = this
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        runningInstance = null
    }

    data class NotificationData(
        val appPackage: String,
        val appName: String,
        val title: String?,
        val text: String?,
        val sbn: StatusBarNotification
    )

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val notification = sbn.notification
        val extras = notification.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()

        // Skip Agent's own notifications and silent/system ones with no text
        if (sbn.packageName == packageName || text.isNullOrBlank()) return

        val appName = try {
            packageManager.getApplicationLabel(
                packageManager.getApplicationInfo(sbn.packageName, 0)
            ).toString()
        } catch (e: Exception) {
            sbn.packageName
        }

        val data = NotificationData(sbn.packageName, appName, title, text, sbn)
        lastNotification = data
        listener?.invoke(data)
        Log.d(TAG, "Notification from $appName: $title - $text")
    }

    /**
     * Sends a reply using the notification's own RemoteInput reply action
     * (the same "quick reply" box you see when you long-press a notification).
     * Only works if the app (e.g. WhatsApp) provided a reply action.
     */
    fun sendQuickReply(sbn: StatusBarNotification, replyText: String): Boolean {
        val action = sbn.notification.actions?.firstOrNull { action ->
            action.remoteInputs != null && action.remoteInputs.isNotEmpty()
        } ?: return false

        val remoteInputs = action.remoteInputs ?: return false
        val intent = Intent()
        val bundle = Bundle()
        for (remoteInput in remoteInputs) {
            bundle.putCharSequence(remoteInput.resultKey, replyText)
        }
        RemoteInput.addResultsToIntent(remoteInputs, intent, bundle)

        return try {
            action.actionIntent.send(this, 0, intent)
            true
        } catch (e: Exception) {
            Log.e(TAG, "Reply failed: ${e.message}")
            false
        }
    }
}
