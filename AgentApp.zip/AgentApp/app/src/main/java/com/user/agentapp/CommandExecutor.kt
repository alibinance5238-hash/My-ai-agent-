package com.user.agentapp

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast

/**
 * Handles "open X" style commands — either a known installed app (via its
 * package name) or a website fallback if no app is found.
 */
object CommandExecutor {

    // Common apps the user mentioned. Add more package names as needed.
    private val KNOWN_APPS = mapOf(
        "tiktok" to "com.zhiliaoapp.musically",
        "ebay" to "com.ebay.mobile",
        "youtube" to "com.google.android.youtube",
        "instagram" to "com.instagram.android",
        "google ads" to "com.google.android.apps.adwords"
    )

    private val KNOWN_WEBSITES = mapOf(
        "tiktok" to "https://www.tiktok.com",
        "ebay" to "https://www.ebay.com",
        "youtube" to "https://www.youtube.com",
        "instagram" to "https://www.instagram.com",
        "cj dropshipping" to "https://cjdropshipping.com",
        "google ads" to "https://ads.google.com"
    )

    /**
     * Looks for a simple "open <app>" phrase in free text (Roman Urdu/English).
     * Returns a status message if it handled the request, or null if this
     * wasn't an "open app" style message (so the caller should send it to
     * Claude instead).
     */
    fun tryOpenAppFromText(context: Context, text: String): String? {
        val lower = text.lowercase()
        val isOpenCommand = lower.contains("kholo") || lower.contains("open") || lower.contains("khol")
        if (!isOpenCommand) return null

        for ((name, pkg) in KNOWN_APPS) {
            if (lower.contains(name)) {
                return openApp(context, name, pkg)
            }
        }
        return null
    }

    /** Called after Claude's reply, in case it embedded an [ACTION:OPEN_APP:name] instruction. */
    fun tryExecuteScreenAction(context: Context, claudeReply: String) {
        val regex = Regex("""\[ACTION:OPEN_APP:(.+?)]""")
        val match = regex.find(claudeReply) ?: return
        val appName = match.groupValues[1].trim().lowercase()
        val pkg = KNOWN_APPS[appName]
        if (pkg != null) {
            openApp(context, appName, pkg)
        } else {
            openWebsite(context, appName)
        }
    }

    private fun openApp(context: Context, name: String, packageName: String): String {
        val launchIntent = context.packageManager.getLaunchIntentForPackage(packageName)
        return if (launchIntent != null) {
            context.startActivity(launchIntent)
            "$name khol raha hoon."
        } else {
            // App not installed — fall back to website or Play Store
            val opened = openWebsite(context, name)
            if (opened) "$name app installed nahi hai, website khol di."
            else "$name nahi mila. Play Store se install karein."
        }
    }

    private fun openWebsite(context: Context, name: String): Boolean {
        val url = KNOWN_WEBSITES[name] ?: return false
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        return true
    }
}
