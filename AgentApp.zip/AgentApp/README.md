# Agent — Aapka Personal Business Automation App

## Yeh App Kya Karta Hai
- Aap se chat/voice mein baat karta hai (Claude AI se connected)
- "Agent, TikTok kholo" / "Agent, eBay kholo" bolne par woh app khud khulti hai
- Screen padh sakta hai aur non-sensitive form fields fill kar sakta hai (Accessibility Service)
- Dropshipping product research, eBay listing content, YouTube scripts, ebook writing, ad copy — sab Claude se generate hota hai chat ke andar

## Kya Yeh KABHI Nahi Karega (Code Mein Hard-Blocked Hai)
`AgentAccessibilityService.kt` mein `isSensitiveField()` function check karta hai aur **kabhi type nahi karega** in fields mein:
- Password fields
- OTP / verification code / passcode
- PIN
- CVV / CVC / card number

Yeh sirf ek "instruction" nahi hai jo AI ignore kar sake — yeh actual code condition hai jo hamesha chalti hai, chahe AI kuch bhi bole.

## Install Karne Ke Liye Kya Chahiye
1. **Android Studio** (free, developer install karega ya aap khud seekh kar)
2. Is poore folder ko Android Studio mein "Open" karein
3. `ClaudeClient.kt` mein apni Anthropic API key daalein (console.anthropic.com se milti hai)
   - **Better tareeka**: API key seedha app mein daalne ke bajaye, apna khud ka chota backend server banayein jo key hold kare — warna koi bhi app ka APK khol kar key nikaal sakta hai
4. Phone ko USB se connect karein (Developer Mode ON), ya emulator use karein
5. "Run" dabayein — app phone pe install ho jayegi

## Phone Pe Pehli Baar Chalane Ke Baad
1. App kholein → "Enable Screen Control" button dabayein
2. Settings > Accessibility > Agent → ON karein (yeh step Android khud manually karwata hai, koi app isay skip nahi kar sakti — yeh security ka rule hai)
3. **WhatsApp/notifications ke liye**: Settings > Apps > Special access > Notification access > Agent → ON karein
4. Ab wapas app mein aayein aur bolna/likhna shuru karein

## Voice Se Form Fill Karna (jaise aap chahte thay)
Do tareeke hain:
1. **Jis field pe tap/cursor ho usay bharna**: bolein — `Agent, yahan likho: [value]`
   (pehle us field pe khud tap karein taake focus ho, phir bolein)
2. **Naam se field dhoond kar bharna**: bolein — `naam ki jagah likho: [aapka naam]` ya `address wali jagah likho: [address]`
   (yeh field ka hint/label text match karta hai)

Password/OTP fields dono tareekon mein hamesha skip ho jayenge — koi bypass nahi.

## "Ghar Pe Na Hun Tab Bhi Kaam Kare" — Kya Real Hai
- Notifications background mein aati rahengi aur Agent unhe track karega, aap wapas aake dekh/reply kar sakte hain
- Lekin yeh ek **insaan jaisa independent assistant nahi ban sakta** jo khud faisle kare — kisi bhi sensitive step (payment, account verification, naya kaam shuru karna) pe yeh hamesha aapki maujoodgi/permission maangega
- Yeh Android ki security design hai, sirf is app ki limit nahi — koi bhi real app aisa nahi kar sakti

## Notifications Feature Kaise Kaam Karta Hai
- Jab WhatsApp (ya koi bhi app) pe message aaye, Agent khud chat mein bata dega: "Aapko WhatsApp pe message aaya: ..."
- Reply karne ke liye bolein: `Agent, reply karo: <apka message>`
- Yeh WhatsApp ke apne "quick reply" button (jo notification pe hota hai) ko use karta hai — bilkul waisay jaisay smartwatch se reply hota hai. WhatsApp ka data/login kabhi touch nahi hota.
- **Limit**: agar WhatsApp ne us notification pe quick-reply button nahi diya (kabhi kabhi group settings ya notification type ki wajah se), to yeh kaam nahi karega.

## eBay Account Banane Ka Tareeqa (Permission Checkpoint)
Agent aapki di hui details (naam, email, address) se signup form **khud bhar sakta hai**, lekin:
- CAPTCHA aur email/phone verification wale step pe **hamesha rukega** aur poochega "Kya aap ijazat dete hain aage badhne ki?"
- Yeh eBay ki apni security policy hai (bots ko rokne ke liye) — koi app isay bypass nahi kar sakti, mera app bhi nahi
- Isliye process hoga: Agent form bharta hai → aap verification khud complete karte hain → Agent aage badhta hai

## Abhi Yeh App Adhoori Kyun Hai (Honestly)
Yeh ek **working starter/foundation** hai, production-ready poora product nahi:
- Form-filling abhi basic hai (hint text se field dhoondta hai) — real world mein har app ka layout alag hota hai, isay har app ke hisaab se tune karna padega
- Play Store pe publish karne ke liye Google ki Accessibility Service policy se guzarna hoga (declare karna padega yeh kis liye use ho raha hai)
- eBay/CJ Dropshipping ka koi official automation API nahi hai jo listing "khud" upload kare bina aapke login/action ke — is app se aap draft taiyar karke ek tap mein submit kar sakte hain, poori tarah invisible automation nahi

## Agla Kadam
Bataiye kis part ko pehle refine karna hai:
- Chat/voice interface behtar banana
- eBay app ke specific fields ke liye form-filling tune karna
- Apna backend server banana (API key ko safe rakhne ke liye)
