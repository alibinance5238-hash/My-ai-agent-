# Agent Android App

This is a ready-to-build Android voice-agent project.

## What this build does

- Gemini API chat with conversation history
- Roman Urdu / Urdu / English speech recognition
- Background live voice while the Live Voice switch is ON
- Barge-in: if Agent is speaking and you start talking, Agent stops speaking
- Silent live-voice notification (no notification sound/vibration)
- Direct app opening for common apps such as TikTok, YouTube, WhatsApp, Instagram and Chrome
- Website opening
- Non-sensitive form filling through Android Accessibility
- Visible-button clicking through Android Accessibility
- Optional screen sharing so Gemini can inspect the current screen
- Notification quick-reply support where Android exposes a reply action

## Important Android permissions

1. **Microphone permission** — required for Live Voice.
2. **Accessibility / Screen Control** — required for filling visible fields and clicking visible buttons.
3. **Share Screen** — required only when Gemini needs to see what is currently on screen.
4. **Notification Access** — optional, for notification reading and quick replies.

These permissions cannot safely be enabled automatically by an APK; Android requires the user to grant them.

## Build with GitHub Actions

The workflow is already included at:

`.github/workflows/build-apk.yml`

The workflow supports either:

- a normal Android project directly at repository root, or
- an uploaded Android source ZIP containing `settings.gradle` and `app/`.

The build artifact is named **Agent-Debug-APK**.

## API key

Paste your own Gemini API key into the app and press **SAVE GEMINI API KEY**.

Do **not** put a real API key in GitHub files or commit it to the repository.
