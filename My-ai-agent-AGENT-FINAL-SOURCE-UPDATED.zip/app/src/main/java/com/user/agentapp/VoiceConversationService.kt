package com.user.agentapp

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import android.content.pm.ServiceInfo
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

/**
 * Background voice loop.
 *
 * Important behaviour:
 * - listens continuously while Live Voice is ON
 * - stops TTS as soon as the user starts speaking (barge-in)
 * - understands Roman Urdu / Urdu / English
 * - executes simple local commands before asking Gemini
 * - sends the current screen to Gemini when Screen Share is ON
 */
class VoiceConversationService : Service(), RecognitionListener, TextToSpeech.OnInitListener {
    companion object {
        const val ACTION_START = "com.user.agentapp.START_VOICE"
        const val ACTION_STOP = "com.user.agentapp.STOP_VOICE"
        const val CHANNEL_ID = "agent_voice"
        const val NOTIFICATION_ID = 3001
        const val EXTRA_STATUS = "voice_status"
        var running = false
            private set
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val handler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var processing = false
    private var userIsSpeaking = false
    private var agentSpeaking = false
    private var audioManager: AudioManager? = null
    private var focusRequest: AudioFocusRequest? = null
    private var lastRms = 0f

    override fun onCreate() {
        super.onCreate()
        createChannel()
        audioManager = getSystemService(AUDIO_SERVICE) as AudioManager
        tts = TextToSpeech(this, this)
        ServiceCompat.startForeground(
            this,
            NOTIFICATION_ID,
            buildNotification("Live Voice ON — Agent sun raha hai"),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopSelf()
            ACTION_START, null -> startVoice()
        }
        return START_NOT_STICKY
    }

    private fun startVoice() {
        if (running) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            sendStatus("Speech recognition available nahi hai.")
            stopSelf()
            return
        }

        running = true
        processing = false
        requestAudioFocus()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(this)
        startListeningSoon(150)
    }

    private fun startListeningSoon(delayMs: Long = 250) {
        handler.postDelayed({ startListening() }, delayMs)
    }

    private fun startListening() {
        if (!running || processing || userIsSpeaking) return

        try {
            recognizer?.cancel()
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ur-PK")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ur-PK")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 850)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 650)
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            }
            recognizer?.startListening(intent)
        } catch (e: Exception) {
            sendStatus("Mic start nahi hua: ${e.message ?: "unknown error"}")
            startListeningSoon(700)
        }
    }

    override fun onDestroy() {
        running = false
        processing = false
        userIsSpeaking = false
        handler.removeCallbacksAndMessages(null)
        recognizer?.cancel()
        recognizer?.destroy()
        recognizer = null
        tts?.stop()
        tts?.shutdown()
        tts = null
        ttsReady = false
        agentSpeaking = false
        abandonAudioFocus()
        scope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onReadyForSpeech(params: Bundle?) {
        sendStatus("Sun raha hoon...")
    }

    override fun onBeginningOfSpeech() {
        userIsSpeaking = true
        // Barge-in: user starts talking -> Agent immediately becomes silent.
        if (agentSpeaking) {
            tts?.stop()
            agentSpeaking = false
        }
        sendStatus("Aap bol rahe hain...")
    }

    override fun onRmsChanged(rmsdB: Float) {
        lastRms = rmsdB
        // Some recognizers are slow to fire onBeginningOfSpeech. If the mic level
        // rises while TTS is playing, stop TTS immediately as a second safety net.
        if (agentSpeaking && rmsdB > 2.5f) {
            tts?.stop()
            agentSpeaking = false
        }
    }

    override fun onBufferReceived(buffer: ByteArray?) {}

    override fun onEndOfSpeech() {
        userIsSpeaking = false
    }

    override fun onEvent(eventType: Int, params: Bundle?) {}

    override fun onPartialResults(partialResults: Bundle?) {
        val text = partialResults
            ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            ?.firstOrNull()
            .orEmpty()
            .trim()

        if (text.isNotBlank() && agentSpeaking) {
            // Partial result means the user is actually speaking. Cut TTS now,
            // not after the final result arrives.
            tts?.stop()
            agentSpeaking = false
        }
    }

    override fun onResults(results: Bundle?) {
        userIsSpeaking = false
        val spoken = results
            ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            ?.firstOrNull()
            .orEmpty()
            .trim()

        if (spoken.isBlank() || !running) {
            if (running && !processing) startListeningSoon(250)
            return
        }

        if (agentSpeaking) {
            tts?.stop()
            agentSpeaking = false
        }

        processSpeech(spoken)
    }

    override fun onError(error: Int) {
        if (!running) return
        userIsSpeaking = false
        if (processing) return

        // ERROR_NO_MATCH / ERROR_SPEECH_TIMEOUT are normal in an always-listening
        // loop. Restart quietly; do not speak an error message through TTS.
        handler.postDelayed({ startListening() }, 350)
    }

    private fun processSpeech(spoken: String) {
        if (processing || !running) return
        processing = true
        recognizer?.cancel()
        tts?.stop()
        agentSpeaking = false
        sendStatus("Aap: $spoken")

        scope.launch {
            // Handle deterministic local commands first. This makes "TikTok kholo",
            // "YouTube kholo", etc. work even if Gemini is slow or unavailable.
            val local = CommandExecutor.executeVoiceCommand(this@VoiceConversationService, spoken)
            if (local != null) {
                sendStatus("Agent: ${local.message}")
                speakThenListen(local.message)
                return@launch
            }

            val screen = ScreenShareService.latestJpeg
            val rawReply = withContext(Dispatchers.IO) {
                GeminiClient.ask(this@VoiceConversationService, spoken, screen)
            }

            val actionResult = CommandExecutor.executeGeminiActions(this@VoiceConversationService, rawReply)
            val spokenReply = CommandExecutor.cleanReply(rawReply)
            val finalReply = when {
                actionResult.isNotBlank() && spokenReply == "Ho gaya." -> actionResult
                actionResult.isNotBlank() && spokenReply.isBlank() -> actionResult
                else -> spokenReply
            }

            sendStatus("Agent: $finalReply")
            speakThenListen(finalReply)
        }
    }

    private fun speakThenListen(text: String) {
        processing = false

        if (!running) return
        if (!ttsReady || text.isBlank()) {
            agentSpeaking = false
            startListeningSoon(250)
            return
        }

        tts?.stop()
        agentSpeaking = true
        val result = tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "agent_reply")

        if (result != TextToSpeech.SUCCESS) {
            agentSpeaking = false
            startListeningSoon(250)
            return
        }

        // Listen during TTS so the user can interrupt. onBeginningOfSpeech/
        // onPartialResults/onRmsChanged will stop TTS immediately.
        startListeningSoon(180)
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        if (!ttsReady) return

        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                if (utteranceId == "agent_reply") agentSpeaking = true
            }

            override fun onDone(utteranceId: String?) {
                if (utteranceId == "agent_reply") {
                    agentSpeaking = false
                    if (running && !userIsSpeaking && !processing) {
                        startListeningSoon(120)
                    }
                }
            }

            override fun onError(utteranceId: String?) {
                if (utteranceId == "agent_reply") {
                    agentSpeaking = false
                    if (running && !processing) startListeningSoon(150)
                }
            }
        })

        // Prefer Urdu TTS. If the phone has no Urdu voice, use the system's
        // default English voice rather than failing silently.
        val urduResult = tts?.setLanguage(Locale("ur", "PK")) ?: TextToSpeech.ERROR
        if (urduResult == TextToSpeech.LANG_MISSING_DATA || urduResult == TextToSpeech.LANG_NOT_SUPPORTED) {
            tts?.setLanguage(Locale.getDefault())
        }
        tts?.setSpeechRate(0.92f)
        tts?.setPitch(1.0f)
    }

    private fun requestAudioFocus() {
        val manager = audioManager ?: return
        if (Build.VERSION.SDK_INT >= 26) {
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANT)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
            focusRequest = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                .setAudioAttributes(attrs)
                .setAcceptsDelayedFocusGain(false)
                .build()
            manager.requestAudioFocus(focusRequest!!)
        } else {
            @Suppress("DEPRECATION")
            manager.requestAudioFocus(null, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
        }
    }

    private fun abandonAudioFocus() {
        val manager = audioManager ?: return
        if (Build.VERSION.SDK_INT >= 26) {
            focusRequest?.let { manager.abandonAudioFocusRequest(it) }
        } else {
            @Suppress("DEPRECATION")
            manager.abandonAudioFocus(null)
        }
    }

    private fun sendStatus(text: String) {
        val intent = Intent("com.user.agentapp.VOICE_STATUS").apply {
            setPackage(packageName)
            putExtra(EXTRA_STATUS, text)
        }
        sendBroadcast(intent)
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Agent live voice", NotificationManager.IMPORTANCE_LOW).apply {
                    setSound(null, null)
                    enableVibration(false)
                }
            )
        }
    }

    private fun buildNotification(text: String): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Agent")
            .setContentText(text)
            .setOngoing(true)
            .setSilent(true)
            .build()
}
