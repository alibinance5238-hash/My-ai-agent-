package com.user.agentapp

import android.content.Context
import android.util.Base64
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** Gemini client for Agent. Keeps the conversation and returns natural Roman Urdu by default. */
object GeminiClient {
    private const val PREFS = "agent_settings"
    private const val API_KEY_PREF = "gemini_api_key"
    private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent"

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val lock = Any()
    private val history = mutableListOf<JSONObject>()

    private const val SYSTEM_PROMPT = """
You are Agent, a practical Android voice assistant.

LANGUAGE:
- Understand spoken Urdu, Roman Urdu, English, and mixed Urdu-English.
- Normally answer in simple Roman Urdu because the user prefers Roman Urdu.
- If the user clearly speaks English and wants English, answer in English.
- Never use Devanagari/Hindi script.
- Keep spoken answers short and natural, like a helpful friend.
- Do not say technical filler such as 'I am an AI language model'.

SCREEN/ACTION MODE:
The Android app can see the current screen when Screen Share is ON and can use Accessibility for non-sensitive fields/buttons.
The app also executes simple commands locally, so do not pretend an action happened unless an action line is appropriate.
For an installed app, return:
[ACTION:OPEN_APP:App Name]
For a website, return:
[ACTION:OPEN_URL:https://example.com]
For a visible non-sensitive field, return:
[ACTION:FILL:field keyword:value]
For a visible non-sensitive button, return:
[ACTION:CLICK:button text]
Put each action on its own line. Do not put actions inside a Markdown code block.
After action lines, give one short natural Roman Urdu confirmation.
For commands that require seeing the screen, if no screen image is available, say that Screen Share needs to be ON.

IMPORTANT:
- Never request, type, store, or handle passwords, OTPs, PINs, CVV, card numbers, verification codes, recovery codes, or payment secrets.
- Never generate an action for a sensitive field.
- If a task reaches a sensitive/payment/security checkpoint, tell the user to take over.
- Do not invent that an action succeeded. If the screen image does not show enough information, ask a short clarification.
""".trimIndent()

    fun saveApiKey(context: Context, key: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(API_KEY_PREF, key.trim()).apply()
    }

    fun hasApiKey(context: Context): Boolean = getApiKey(context).isNotBlank()

    private fun getApiKey(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(API_KEY_PREF, "")?.trim().orEmpty()

    fun clearConversation() {
        synchronized(lock) { history.clear() }
    }

    fun ask(context: Context, userMessage: String, screenJpeg: ByteArray? = null): String {
        val apiKey = getApiKey(context)
        if (apiKey.isBlank()) return "Pehle Gemini API key save karo."

        return try {
            val contents = JSONArray()
            synchronized(lock) {
                history.forEach { contents.put(JSONObject(it.toString())) }
            }

            val parts = JSONArray()
            parts.put(JSONObject().put("text", userMessage))

            if (screenJpeg != null) {
                val encoded = Base64.encodeToString(screenJpeg, Base64.NO_WRAP)
                parts.put(
                    JSONObject().put(
                        "inline_data",
                        JSONObject()
                            .put("mime_type", "image/jpeg")
                            .put("data", encoded)
                    )
                )
            }

            contents.put(JSONObject().put("role", "user").put("parts", parts))

            val body = JSONObject().apply {
                put(
                    "systemInstruction",
                    JSONObject().put(
                        "parts",
                        JSONArray().put(JSONObject().put("text", SYSTEM_PROMPT))
                    )
                )
                put("contents", contents)
                put(
                    "generationConfig",
                    JSONObject()
                        .put("temperature", 0.4)
                        .put("maxOutputTokens", 700)
                )
            }

            val request = Request.Builder()
                .url(BASE_URL)
                .addHeader("x-goog-api-key", apiKey)
                .addHeader("content-type", "application/json")
                .post(body.toString().toRequestBody("application/json".toMediaType()))
                .build()

            client.newCall(request).execute().use { response ->
                val responseBody = response.body?.string().orEmpty()

                if (!response.isSuccessful) {
                    val detail = try {
                        JSONObject(responseBody).optJSONObject("error")?.optString("message").orEmpty()
                    } catch (_: Exception) { "" }
                    return "Gemini se jawab nahi mila. API key/quota check karo.${if (detail.isNotBlank()) " $detail" else ""}"
                }

                val json = JSONObject(responseBody)
                val candidates = json.optJSONArray("candidates")
                    ?: return "Gemini ne koi jawab nahi diya."
                if (candidates.length() == 0) return "Gemini ne koi jawab nahi diya."

                val responseParts = candidates.getJSONObject(0)
                    .optJSONObject("content")?.optJSONArray("parts")
                    ?: return "Gemini ka jawab read nahi ho saka."

                val answer = StringBuilder()
                for (i in 0 until responseParts.length()) {
                    val text = responseParts.getJSONObject(i).optString("text", "")
                    if (text.isNotBlank()) answer.append(text).append("\n")
                }

                val finalAnswer = answer.toString().trim()
                    .ifBlank { "Mujhe abhi koi text jawab nahi mila." }

                synchronized(lock) {
                    history.add(
                        JSONObject()
                            .put("role", "user")
                            .put("parts", JSONArray().put(JSONObject().put("text", userMessage)))
                    )
                    history.add(
                        JSONObject()
                            .put("role", "model")
                            .put("parts", JSONArray().put(JSONObject().put("text", finalAnswer)))
                    )
                    while (history.size > 20) history.removeAt(0)
                }

                finalAnswer
            }
        } catch (e: Exception) {
            "Gemini connection error: ${e.message ?: "internet ya API issue"}"
        }
    }
}
