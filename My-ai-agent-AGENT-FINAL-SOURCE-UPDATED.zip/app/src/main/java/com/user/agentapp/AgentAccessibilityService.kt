package com.user.agentapp

import android.accessibilityservice.AccessibilityService
import android.os.Bundle
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * This service lets Agent "see" what's on screen and fill in non-sensitive
 * form fields (e.g. a product title box, a search bar, a description field).
 *
 * HARD SAFETY RULE — do not remove:
 * Any field that is a password field, or whose hint/id text suggests it's
 * an OTP, PIN, CVV, card number, or verification code, is skipped entirely.
 * This is enforced in code (isSensitiveField), not just by prompting —
 * so the AI layer above can never override it.
 */
class AgentAccessibilityService : AccessibilityService() {

    companion object {
        var pendingFillValue: String? = null
        var pendingFillFieldHint: String? = null
        const val TAG = "AgentAccessibility"
        // Running instance so MainActivity can call fillFocusedField/fillFieldByKeyword directly
        var runningInstance: AgentAccessibilityService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        runningInstance = this
    }

    override fun onDestroy() {
        super.onDestroy()
        runningInstance = null
    }

    /** Fills whichever field currently has keyboard focus — used for "yahan likho: X" voice commands. */
    fun fillFocusedField(value: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        if (isSensitiveField(focused)) {
            Log.w(TAG, "Blocked: refused to type into a sensitive field.")
            return false
        }
        fillField(focused, value)
        return true
    }

    /** Finds a field whose hint/label text contains a keyword (e.g. "naam", "name", "address") and fills it. */
    fun fillFieldByKeyword(keyword: String, value: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val target = searchNodes(root) { node ->
            node.className == "android.widget.EditText" &&
                (node.hintText?.toString()?.contains(keyword, ignoreCase = true) == true)
        } ?: return false
        if (isSensitiveField(target)) {
            Log.w(TAG, "Blocked: refused to type into a sensitive field.")
            return false
        }
        fillField(target, value)
        return true
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val root = rootInActiveWindow ?: return

        val fillValue = pendingFillValue
        val fieldHint = pendingFillFieldHint
        if (fillValue != null) {
            val target = findFieldByHint(root, fieldHint)
            if (target != null) {
                if (isSensitiveField(target)) {
                    Log.w(TAG, "Blocked: refused to type into a sensitive field.")
                } else {
                    fillField(target, fillValue)
                }
            }
            pendingFillValue = null
            pendingFillFieldHint = null
        }
    }

    override fun onInterrupt() {}

    /** Never type into password/OTP/PIN/CVV/card fields — checked by class, hint text, and resource id. */
    private fun isSensitiveField(node: AccessibilityNodeInfo): Boolean {
        if (node.isPassword) return true

        val sensitiveKeywords = listOf(
            "password", "otp", "one-time", "one time", "pin", "cvv", "cvc",
            "card number", "security code", "verification code", "passcode"
        )

        val hint = node.hintText?.toString()?.lowercase() ?: ""
        val text = node.text?.toString()?.lowercase() ?: ""
        val viewId = node.viewIdResourceName?.lowercase() ?: ""

        return sensitiveKeywords.any { hint.contains(it) || text.contains(it) || viewId.contains(it) }
    }

    private fun findFieldByHint(root: AccessibilityNodeInfo, hint: String?): AccessibilityNodeInfo? {
        if (hint == null) return null
        return searchNodes(root) { node ->
            node.className == "android.widget.EditText" &&
                (node.hintText?.toString()?.contains(hint, ignoreCase = true) == true)
        }
    }

    fun clickByText(label: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val target = searchNodes(root) { node ->
            val text = node.text?.toString().orEmpty()
            val desc = node.contentDescription?.toString().orEmpty()
            text.equals(label, ignoreCase = true) || desc.equals(label, ignoreCase = true)
        } ?: return false

        var current: AccessibilityNodeInfo? = target
        while (current != null) {
            if (current.isClickable) {
                return current.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            }
            current = current.parent
        }
        return false
    }

    private fun searchNodes(
        node: AccessibilityNodeInfo,
        predicate: (AccessibilityNodeInfo) -> Boolean
    ): AccessibilityNodeInfo? {
        if (predicate(node)) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val result = searchNodes(child, predicate)
            if (result != null) return result
        }
        return null
    }

    private fun fillField(node: AccessibilityNodeInfo, value: String) {
        val arguments = Bundle()
        arguments.putCharSequence(
            AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, value
        )
        node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, arguments)
    }
}
