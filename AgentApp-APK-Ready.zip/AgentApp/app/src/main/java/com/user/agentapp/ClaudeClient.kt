package com.user.agentapp

import android.content.Context
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Calls the Anthropic API so Agent can understand requests and write
 * content (product research, video scripts, ebook chapters, ad copy, etc).
 *
 * SETUP REQUIRED: Put your own Anthropic API key below, or better,
 * proxy this through your own backend server so the key isn't sitting
 * inside the compiled app (anyone could extract it otherwise).
 */
object ClaudeClient {

    // TODO: Replace with your own key, or point BASE_URL at your own backend.
    private const val API_KEY_PREF = "anthropic_api_key"
    private const val DEFAULT_API_KEY = "YOUR_ANTHROPIC_API_KEY_HERE"
    private const val BASE_URL = "https://api.anthropic.com/v1/messages"

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    private val SYSTEM_PROMPT = """
        Aap 'Agent' hain — ek business assistant jo dropshipping (CJ Dropshipping + eBay),
        YouTube content (USA niche, policy-safe), ebooks, aur ads (Google/TikTok/Instagram)
        mein madad karta hai. User Roman Urdu/Hindi mix mein baat karega, usi tarah jawab dein.

        Aap kabhi bhi OTP, password, ya payment details nahi maangte aur na hi handle karte hain.
        Aap accounts khud create/login/verify nahi karte — sirf content/research/drafts banate hain.

        Agar user kisi app ya website ko kholne ko kahe (jaise "TikTok kholo", "eBay kholo"),
        apne jawab ke aakhir mein bilkul is format mein ek line likhein:
        [ACTION:OPEN_APP:<app name>]
        Warna yeh line mat likhein.
    """.trimIndent()

    fun saveApiKey(context: Context, key: String) {
        context.getSharedPreferences("agent_settings", Context.MODE_PRIVATE)
            .edit().putString(API_KEY_PREF, key).apply()
    }

    private fun getApiKey(context: Context): String {
        return context.getSharedPreferences("agent_settings", Context.MODE_PRIVATE)
            .getString(API_KEY_PREF, DEFAULT_API_KEY) ?: DEFAULT_API_KEY
    }

    fun ask(context: Context, userMessage: String): String {
        return try {
            val body = JSONObject().apply {
                put("model", "claude-sonnet-4-6")
                put("max_tokens", 1024)
                put("system", SYSTEM_PROMPT)
                put("messages", JSONArray().put(
                    JSONObject().put("role", "user").put("content", userMessage)
                ))
            }

            val request = Request.Builder()
                .url(BASE_URL)
                .addHeader("x-api-key", getApiKey(context))
                .addHeader("anthropic-version", "2023-06-01")
                .addHeader("content-type", "application/json")
                .post(body.toString().toRequestBody("application/json".toMediaType()))
                .build()

            client.newCall(request).execute().use { response ->
                val responseBody = response.body?.string() ?: return "Agent: koi jawab nahi mila."
                if (!response.isSuccessful) {
                    return "Agent error: ${response.code} — API key check karein (ClaudeClient.kt mein)."
                }
                val json = JSONObject(responseBody)
                val content = json.getJSONArray("content")
                val textBuilder = StringBuilder()
                for (i in 0 until content.length()) {
                    val block = content.getJSONObject(i)
                    if (block.getString("type") == "text") {
                        textBuilder.append(block.getString("text"))
                    }
                }
                textBuilder.toString()
            }
        } catch (e: Exception) {
            "Agent connection error: ${e.message}"
        }
    }
}
