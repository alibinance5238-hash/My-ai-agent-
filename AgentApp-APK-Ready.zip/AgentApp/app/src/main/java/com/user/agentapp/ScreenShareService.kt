package com.user.agentapp

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.res.Resources
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import android.content.pm.ServiceInfo
import java.io.ByteArrayOutputStream

/** Captures the current device screen for screen-aware Gemini requests. */
class ScreenShareService : Service() {
    companion object {
        const val ACTION_START = "com.user.agentapp.START_SCREEN_SHARE"
        const val ACTION_STOP = "com.user.agentapp.STOP_SCREEN_SHARE"
        const val EXTRA_RESULT_CODE = "result_code"
        const val CHANNEL_ID = "agent_screen"
        const val NOTIFICATION_ID = 3002

        @Volatile var latestJpeg: ByteArray? = null
            private set
        @Volatile var running = false
            private set
    }

    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var virtualDisplay: android.hardware.display.VirtualDisplay? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        val data = intent?.getParcelableExtraCompat<Intent>("result_data")
        if (resultCode == 0 || data == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        ServiceCompat.startForeground(this, NOTIFICATION_ID, buildNotification("Agent screen sharing ON"), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        startCapture(resultCode, data)
        return START_STICKY
    }

    private fun startCapture(resultCode: Int, data: Intent) {
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = manager.getMediaProjection(resultCode, data)
        val metrics = Resources.getSystem().displayMetrics
        val width = metrics.widthPixels.coerceAtMost(1440)
        val height = metrics.heightPixels.coerceAtMost(2560)
        val density = metrics.densityDpi

        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        reader?.setOnImageAvailableListener({ imageReader ->
            val image = imageReader.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                val plane = image.planes[0]
                val pixelStride = plane.pixelStride
                val rowStride = plane.rowStride
                val rowPadding = rowStride - pixelStride * width
                val bitmapWidth = width + rowPadding / pixelStride
                val bitmap = Bitmap.createBitmap(bitmapWidth, height, Bitmap.Config.ARGB_8888)
                bitmap.copyPixelsFromBuffer(plane.buffer)
                val cropped = if (bitmapWidth != width) Bitmap.createBitmap(bitmap, 0, 0, width, height) else bitmap
                val out = ByteArrayOutputStream()
                cropped.compress(Bitmap.CompressFormat.JPEG, 55, out)
                latestJpeg = out.toByteArray()
                if (cropped !== bitmap) cropped.recycle()
                bitmap.recycle()
            } catch (_: Exception) {
            } finally {
                image.close()
            }
        }, null)

        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, null)
        virtualDisplay = projection?.createVirtualDisplay(
            "AgentScreen",
            width,
            height,
            density,
            android.hardware.display.DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader?.surface,
            null,
            null
        )
        running = true
    }

    override fun onDestroy() {
        running = false
        latestJpeg = null
        virtualDisplay?.release()
        reader?.close()
        projection?.stop()
        virtualDisplay = null
        reader = null
        projection = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Agent screen sharing", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun buildNotification(text: String): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("Agent")
            .setContentText(text)
            .setOngoing(true)
            .build()
}

@Suppress("DEPRECATION")
private inline fun <reified T : android.os.Parcelable> Intent.getParcelableExtraCompat(name: String): T? {
    return if (Build.VERSION.SDK_INT >= 33) getParcelableExtra(name, T::class.java) else getParcelableExtra(name)
}
