package com.user.agentapp

import android.content.Context
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** Gemini API client. Uses the free-tier Gemini 2.5 Flash model when the
 * Google AI Studio key has free-tier quota available. */
object GeminiClient {
    private const val PREFS = "agent_settings"
    private const val API_KEY_PREF = "gemini_api_key"
    private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent"

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    private val lock = Any()
    private val history = mutableListOf<JSONObject>()

    private const val SYSTEM_PROMPT = """
        You are Agent, a practical Android assistant. Understand Roman Urdu, Urdu,
        English, and mixed informal speech. Answer naturally and briefly in the
        user's language. You help with research, websites, apps, forms, business
        workflows and screen-aware tasks.

        Safety: Never ask for, type, store, or handle passwords, OTPs, PINs, CVV,
        card numbers, verification codes, or payment secrets. Stop and ask the
        user to take over at those checkpoints.

        If the user asks to open an app, you may return [ACTION:OPEN_APP:app name]
        on its own line. Otherwise do not emit that action.
    """.trimIndent()

    fun saveApiKey(context: Context, key: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(API_KEY_PREF, key).apply()
    }

    fun hasApiKey(context: Context): Boolean = getApiKey(context).isNotBlank()

    private fun getApiKey(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(API_KEY_PREF, "")?.trim().orEmpty()

    fun clearConversation() {
        synchronized(lock) { history.clear() }
    }

    fun ask(context: Context, userMessage: String, screenJpeg: ByteArray? = null): String {
        val apiKey = getApiKey(context)
        if (apiKey.isBlank()) return "Agent: Pehle Google Gemini API key save karein."

        return try {
            val contents = JSONArray()
            synchronized(lock) {
                history.forEach { contents.put(JSONObject(it.toString())) }
            }

            val parts = JSONArray().apply {
                put(JSONObject().put("text", userMessage))
                if (screenJpeg != null) {
                    put(JSONObject().put("inline_data", JSONObject()
                        .put("mime_type", "image/jpeg")
                        .put("data", android.util.Base64.encodeToString(screenJpeg, android.util.Base64.NO_WRAP)))
                }
            }
            contents.put(JSONObject().put("role", "user").put("parts", parts))

            val body = JSONObject().apply {
                put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM_PROMPT))))
                put("contents", contents)
                put("generationConfig", JSONObject().put("maxOutputTokens", 1024))
            }

            val request = Request.Builder()
                .url(BASE_URL)
                .addHeader("x-goog-api-key", apiKey)
                .addHeader("content-type", "application/json")
                .post(body.toString().toRequestBody("application/json".toMediaType()))
                .build()

            client.newCall(request).execute().use { response ->
                val responseBody = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return "Agent error: ${response.code}. Gemini API key, free quota, ya internet check karein."
                }

                val json = JSONObject(responseBody)
                val candidates = json.optJSONArray("candidates")
                    ?: return "Agent: Gemini ne koi jawab nahi diya."
                if (candidates.length() == 0) return "Agent: Gemini ne koi jawab nahi diya."

                val responseParts = candidates.getJSONObject(0)
                    .optJSONObject("content")?.optJSONArray("parts")
                    ?: return "Agent: jawab read nahi ho saka."

                val answer = StringBuilder()
                for (i in 0 until responseParts.length()) {
                    val text = responseParts.getJSONObject(i).optString("text", "")
                    if (text.isNotBlank()) answer.append(text)
                }
                val finalAnswer = answer.toString().trim().ifBlank { "Agent: koi text jawab nahi mila." }

                synchronized(lock) {
                    history.add(JSONObject()
                        .put("role", "user")
                        .put("parts", JSONArray().put(JSONObject().put("text", userMessage))))
                    history.add(JSONObject()
                        .put("role", "model")
                        .put("parts", JSONArray().put(JSONObject().put("text", finalAnswer))))
                    while (history.size > 20) history.removeAt(0)
                }
                finalAnswer
            }
        } catch (e: Exception) {
            "Agent connection error: ${e.message ?: "unknown error"}"
        }
    }
}
