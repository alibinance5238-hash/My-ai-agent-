package com.user.agentapp

import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.text.method.ScrollingMovementMethod
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var chatLog: TextView
    private lateinit var inputBox: EditText
    private lateinit var statusText: TextView
    private val VOICE_REQUEST_CODE = 100

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        chatLog = findViewById(R.id.chatLog)
        inputBox = findViewById(R.id.inputBox)
        statusText = findViewById(R.id.statusText)
        chatLog.movementMethod = ScrollingMovementMethod()

        findViewById<Button>(R.id.enableAccessibilityBtn).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        findViewById<Button>(R.id.saveApiKeyButton).setOnClickListener {
            val key = findViewById<EditText>(R.id.apiKeyBox).text.toString().trim()
            if (key.isBlank()) {
                Toast.makeText(this, "Anthropic API key paste karein", Toast.LENGTH_SHORT).show()
            } else {
                ClaudeClient.saveApiKey(this, key)
                Toast.makeText(this, "API key phone mein save ho gayi", Toast.LENGTH_SHORT).show()
            }
        }

        findViewById<Button>(R.id.notificationAccessBtn).setOnClickListener {
            startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
        }

        findViewById<Button>(R.id.sendButton).setOnClickListener {
            val text = inputBox.text.toString().trim()
            if (text.isNotEmpty()) {
                handleUserMessage(text)
                inputBox.setText("")
            }
        }

        findViewById<Button>(R.id.micButton).setOnClickListener {
            startVoiceInput()
        }
    }

    override fun onResume() {
        super.onResume()
        updateAccessibilityStatus()
        // Whenever a notification arrives, announce it in the chat automatically
        AgentNotificationListener.listener = { data ->
            runOnUiThread {
                appendChat("Agent", "Aapko ${data.appName} pe message aaya: \"${data.title ?: ""} - ${data.text}\". Reply karna hai to bolein: 'Agent, reply karo: <text>'")
            }
        }
    }

    override fun onPause() {
        super.onPause()
        AgentNotificationListener.listener = null
    }

    private fun updateAccessibilityStatus() {
        val enabled = isAccessibilityServiceEnabled()
        statusText.text = if (enabled)
            "Accessibility Service: ON — Agent screen control kar sakta hai"
        else
            "Accessibility Service: OFF — upar wala button dabayein"
    }

    private fun isAccessibilityServiceEnabled(): Boolean {
        val expected = "$packageName/${AgentAccessibilityService::class.java.canonicalName}"
        val enabledServices = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabledServices.contains(expected)
    }

    private fun startVoiceInput() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Agent ko bolein...")
        try {
            startActivityForResult(intent, VOICE_REQUEST_CODE)
        } catch (e: Exception) {
            Toast.makeText(this, "Voice input available nahi hai is device par", Toast.LENGTH_SHORT).show()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == VOICE_REQUEST_CODE && data != null) {
            val results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val spoken = results?.get(0) ?: return
            handleUserMessage(spoken)
        }
    }

    private fun appendChat(sender: String, message: String) {
        chatLog.append("\n\n$sender: $message")
    }

    private fun handleUserMessage(message: String) {
        appendChat("Aap", message)

        val lower = message.lowercase()

        // 0.5 "yahan likho: X" -> fills whichever field is currently focused/tapped
        if (lower.startsWith("yahan likho") || lower.startsWith("agent, yahan likho") || lower.contains("yahan likho:")) {
            val value = message.substringAfter(":").trim()
            val service = AgentAccessibilityService.runningInstance
            if (service == null) {
                appendChat("Agent", "Screen Control ON nahi hai. Pehle 'Enable Screen Control' button dabayein.")
            } else {
                val ok = service.fillFocusedField(value)
                appendChat("Agent", if (ok) "Likh diya: \"$value\"" else "Yeh field bhar nahi saka — shayad koi field select/tap nahi hai, ya yeh sensitive field hai (password/OTP).")
            }
            return
        }

        // 0.6 "naam ki jagah likho: X" / "address wali jagah likho: X" -> finds field by label keyword
        val keywordFillRegex = Regex("""(\S+)\s*(ki jagah|wali jagah|field mein)\s*likho[:\s]+(.+)""", RegexOption.IGNORE_CASE)
        val kwMatch = keywordFillRegex.find(message)
        if (kwMatch != null) {
            val keyword = kwMatch.groupValues[1]
            val value = kwMatch.groupValues[3].trim()
            val service = AgentAccessibilityService.runningInstance
            if (service == null) {
                appendChat("Agent", "Screen Control ON nahi hai. Pehle 'Enable Screen Control' button dabayein.")
            } else {
                val ok = service.fillFieldByKeyword(keyword, value)
                appendChat("Agent", if (ok) "\"$keyword\" wali jagah likh diya: \"$value\"" else "Woh field nahi mila is screen par.")
            }
            return
        }

        // 0. "reply karo: <text>" -> send via the last notification's own reply button
        if (lower.startsWith("reply karo") || lower.startsWith("agent, reply karo") || lower.contains("reply karo:")) {
            val replyText = message.substringAfter(":").trim()
            val last = AgentNotificationListener.lastNotification
            val service = AgentNotificationListener.runningInstance
            if (last != null && replyText.isNotEmpty() && service != null) {
                val sent = service.sendQuickReply(last.sbn, replyText)
                appendChat("Agent", if (sent) "Reply bhej diya: \"$replyText\"" else "Reply nahi bhej saka — is app mein quick-reply button available nahi hai.")
                return
            } else if (service == null) {
                appendChat("Agent", "Notification access ON nahi hai. Settings > Notification Access > Agent ON karein pehle.")
                return
            }
        }

        // 1. Check for direct "open X app" commands first — instant, no AI call needed
        val opened = CommandExecutor.tryOpenAppFromText(this, message)
        if (opened != null) {
            appendChat("Agent", opened)
            return
        }

        // 2. Otherwise, send to Claude for interpretation / content generation
        CoroutineScope(Dispatchers.Main).launch {
            appendChat("Agent", "...")
            val reply = withContext(Dispatchers.IO) {
                ClaudeClient.ask(this@MainActivity, message)
            }
            // remove the "..." placeholder line
            chatLog.text = chatLog.text.toString().removeSuffix("\n\nAgent: ...")
            appendChat("Agent", reply)

            // 3. If Claude's reply contains a screen action instruction, execute it
            CommandExecutor.tryExecuteScreenAction(this@MainActivity, reply)
        }
    }
}
