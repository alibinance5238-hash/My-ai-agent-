package com.user.agentapp

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.SpeechRecognizer
import android.text.method.ScrollingMovementMethod
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.ContextCompat.registerReceiver
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var chatLog: TextView
    private lateinit var inputBox: EditText
    private lateinit var statusText: TextView
    private lateinit var apiKeyBox: EditText
    private val SCREEN_REQUEST_CODE = 500
    private val AUDIO_PERMISSION_CODE = 501

    private val voiceReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val text = intent?.getStringExtra(VoiceConversationService.EXTRA_STATUS) ?: return
            appendChat("Live", text)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        chatLog = findViewById(R.id.chatLog)
        inputBox = findViewById(R.id.inputBox)
        statusText = findViewById(R.id.statusText)
        apiKeyBox = findViewById(R.id.apiKeyBox)
        chatLog.movementMethod = ScrollingMovementMethod()

        findViewById<Button>(R.id.enableAccessibilityBtn).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        findViewById<Button>(R.id.saveApiKeyButton).setOnClickListener {
            val key = apiKeyBox.text.toString().trim()
            if (key.isBlank()) {
                Toast.makeText(this, "Gemini API key paste karein", Toast.LENGTH_SHORT).show()
            } else {
                GeminiClient.saveApiKey(this, key)
                Toast.makeText(this, "Gemini API key phone mein save ho gayi", Toast.LENGTH_SHORT).show()
            }
        }

        findViewById<Button>(R.id.notificationAccessBtn).setOnClickListener {
            startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
        }

        findViewById<Button>(R.id.screenShareBtn).setOnClickListener {
            requestScreenShare()
        }

        findViewById<Button>(R.id.liveVoiceBtn).setOnClickListener {
            toggleLiveVoice()
        }

        findViewById<Button>(R.id.sendButton).setOnClickListener {
            val text = inputBox.text.toString().trim()
            if (text.isNotEmpty()) {
                handleUserMessage(text)
                inputBox.setText("")
            }
        }

        // This is now programmatic SpeechRecognizer, not ACTION_RECOGNIZE_SPEECH,
        // so tapping the button does not launch the large Google voice popup.
        findViewById<Button>(R.id.micButton).setOnClickListener {
            oneShotVoiceInput()
        }

        updateAccessibilityStatus()
        updateButtons()
    }

    override fun onResume() {
        super.onResume()
        updateAccessibilityStatus()
        updateButtons()
        AgentNotificationListener.listener = { data ->
            runOnUiThread {
                appendChat("Agent", "Aapko ${data.appName} pe message aaya: \"${data.title ?: ""} - ${data.text}\". Reply karna hai to bolein: 'reply karo: <text>'")
            }
        }
        val filter = IntentFilter("com.user.agentapp.VOICE_STATUS")
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(voiceReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(voiceReceiver, filter)
        }
    }

    override fun onPause() {
        AgentNotificationListener.listener = null
        try { unregisterReceiver(voiceReceiver) } catch (_: Exception) {}
        super.onPause()
    }

    private fun updateButtons() {
        findViewById<Button>(R.id.liveVoiceBtn).text = if (VoiceConversationService.running) {
            "STOP LIVE VOICE"
        } else {
            "START LIVE VOICE (BACKGROUND)"
        }
        findViewById<Button>(R.id.screenShareBtn).text = if (ScreenShareService.running) {
            "STOP SCREEN SHARE"
        } else {
            "SHARE SCREEN WITH AGENT"
        }
    }

    private fun updateAccessibilityStatus() {
        val enabled = isAccessibilityServiceEnabled()
        statusText.text = if (enabled)
            "Accessibility: ON — Agent screen controls/read kar sakta hai"
        else
            "Accessibility: OFF — Enable Screen Control dabayein"
    }

    private fun isAccessibilityServiceEnabled(): Boolean {
        val expected = "$packageName/${AgentAccessibilityService::class.java.canonicalName}"
        val enabledServices = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabledServices.contains(expected)
    }

    private fun ensureAudioPermission(): Boolean {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            return true
        }
        ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), AUDIO_PERMISSION_CODE)
        return false
    }

    private fun toggleLiveVoice() {
        if (VoiceConversationService.running) {
            stopService(Intent(this, VoiceConversationService::class.java).setAction(VoiceConversationService.ACTION_STOP))
            updateButtons()
            return
        }
        if (!ensureAudioPermission()) return
        if (!GeminiClient.hasApiKey(this)) {
            Toast.makeText(this, "Pehle Gemini API key save karein", Toast.LENGTH_LONG).show()
            return
        }
        val intent = Intent(this, VoiceConversationService::class.java).setAction(VoiceConversationService.ACTION_START)
        ContextCompat.startForegroundService(this, intent)
        Toast.makeText(this, "Live voice ON — ab app se bahar ja sakte hain", Toast.LENGTH_SHORT).show()
        updateButtons()
    }

    private fun oneShotVoiceInput() {
        if (!ensureAudioPermission()) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "Speech recognition available nahi hai", Toast.LENGTH_SHORT).show()
            return
        }

        val recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer.setRecognitionListener(object : android.speech.RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onError(error: Int) {
                recognizer.destroy()
                Toast.makeText(this@MainActivity, "Voice samajh nahi aayi — dobara bolen", Toast.LENGTH_SHORT).show()
            }
            override fun onResults(results: Bundle?) {
                val spoken = results?.getStringArrayList(android.speech.SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull().orEmpty().trim()
                recognizer.destroy()
                if (spoken.isNotBlank()) handleUserMessage(spoken)
            }
        })
        val intent = Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL, android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(android.speech.RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        }
        recognizer.startListening(intent)
    }

    private fun requestScreenShare() {
        if (ScreenShareService.running) {
            stopService(Intent(this, ScreenShareService::class.java).setAction(ScreenShareService.ACTION_STOP))
            updateButtons()
            return
        }
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), SCREEN_REQUEST_CODE)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == SCREEN_REQUEST_CODE && resultCode == RESULT_OK && data != null) {
            val serviceIntent = Intent(this, ScreenShareService::class.java).apply {
                action = ScreenShareService.ACTION_START
                putExtra(ScreenShareService.EXTRA_RESULT_CODE, resultCode)
                putExtra("result_data", data)
            }
            ContextCompat.startForegroundService(this, serviceIntent)
            Toast.makeText(this, "Screen sharing ON", Toast.LENGTH_SHORT).show()
            updateButtons()
        }
    }

    private fun appendChat(sender: String, message: String) {
        chatLog.append("\n\n$sender: $message")
    }

    private fun handleUserMessage(message: String) {
        appendChat("Aap", message)
        val lower = message.lowercase()

        if (lower.startsWith("yahan likho") || lower.startsWith("agent, yahan likho") || lower.contains("yahan likho:")) {
            val value = message.substringAfter(":").trim()
            val service = AgentAccessibilityService.runningInstance
            if (service == null) {
                appendChat("Agent", "Screen Control ON nahi hai. Pehle Enable Screen Control dabayein.")
            } else {
                val ok = service.fillFocusedField(value)
                appendChat("Agent", if (ok) "Likh diya: \"$value\"" else "Yeh field bhar nahi saka — password/OTP ya unsupported field ho sakti hai.")
            }
            return
        }

        val keywordFillRegex = Regex("""(\\S+)\\s*(ki jagah|wali jagah|field mein)\\s*likho[:\\s]+(.+)""", RegexOption.IGNORE_CASE)
        val kwMatch = keywordFillRegex.find(message)
        if (kwMatch != null) {
            val keyword = kwMatch.groupValues[1]
            val value = kwMatch.groupValues[3].trim()
            val service = AgentAccessibilityService.runningInstance
            if (service == null) {
                appendChat("Agent", "Screen Control ON nahi hai. Pehle Enable Screen Control dabayein.")
            } else {
                val ok = service.fillFieldByKeyword(keyword, value)
                appendChat("Agent", if (ok) "\"$keyword\" wali jagah likh diya: \"$value\"" else "Woh field nahi mila is screen par.")
            }
            return
        }

        if (lower.startsWith("reply karo") || lower.startsWith("agent, reply karo") || lower.contains("reply karo:")) {
            val replyText = message.substringAfter(":").trim()
            val last = AgentNotificationListener.lastNotification
            val service = AgentNotificationListener.runningInstance
            if (last != null && replyText.isNotEmpty() && service != null) {
                val sent = service.sendQuickReply(last.sbn, replyText)
                appendChat("Agent", if (sent) "Reply bhej diya: \"$replyText\"" else "Is notification mein quick-reply available nahi hai.")
                return
            } else if (service == null) {
                appendChat("Agent", "Notification access ON nahi hai.")
                return
            }
        }

        val opened = CommandExecutor.tryOpenAppFromText(this, message)
        if (opened != null) {
            appendChat("Agent", opened)
            return
        }

        CoroutineScope(Dispatchers.Main).launch {
            appendChat("Agent", "...")
            val reply = withContext(Dispatchers.IO) {
                GeminiClient.ask(this@MainActivity, message, ScreenShareService.latestJpeg)
            }
            chatLog.text = chatLog.text.toString().removeSuffix("\n\nAgent: ...")
            appendChat("Agent", reply)
            CommandExecutor.tryExecuteScreenAction(this@MainActivity, reply)
        }
    }
}
