# Agent Android App

A personal Android assistant starter app. It provides chat/voice input, Claude API responses, selected app opening, optional Android Accessibility form filling for non-sensitive fields, and notification reading/reply through Android notification actions.

## Important
- The APK cannot talk to Claude until you paste your own Anthropic API key into the app and tap Save Claude API Key.
- The key is stored locally on the phone for this personal build. Do not distribute this APK with your key inside it.
- Accessibility and Notification Access are optional Android permissions and must be enabled manually.
- Password, OTP, PIN, CVV/CVC, card-number and verification-code fields are blocked by the accessibility code.

## GitHub APK build
Upload the contents of this project to a repository (not the ZIP file nested inside the repository). Then open Actions -> Build Agent APK -> Run workflow. The APK appears under the workflow run's Artifacts as Agent-debug-apk.
