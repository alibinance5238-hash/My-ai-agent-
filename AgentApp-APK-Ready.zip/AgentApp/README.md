# Agent Android App

Agent is a screen-aware Android assistant starter with Gemini API support.

## Current build
- Google Gemini API (Gemini 2.5 Flash) with free-tier quota when available.
- Gemini API key is entered inside the app and stored locally on the device. Never commit a key to GitHub.
- Programmatic speech recognition instead of the large ACTION_RECOGNIZE_SPEECH popup.
- Live Voice foreground service can continue while the app is outside the foreground.
- TTS stops when a new speech result arrives (barge-in behavior).
- Screen Share uses Android MediaProjection and sends the latest captured JPEG to Gemini with the next request.
- Android Accessibility can read/control visible UI and blocks password/OTP/PIN/CVV/payment fields.
- Notification access can read notifications and use supported quick replies.

## Setup
1. Create a Gemini API key in Google AI Studio.
2. Paste it into Agent > Gemini API key and tap Save Gemini API Key.
3. Enable Screen Control in Android Accessibility settings.
4. Optional: tap Share Screen with Agent and approve Android's screen-capture dialog.
5. Optional: tap Start Live Voice and keep the foreground-service notification enabled.

Do not place a real API key in this repository or ZIP.
