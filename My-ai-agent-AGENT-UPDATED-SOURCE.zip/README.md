# Agent Android App

This package is the Android source project for Agent.

## Main features

- Gemini chat using a user-provided API key
- Roman Urdu / Urdu / English understanding
- Background live voice using Android SpeechRecognizer
- Spoken replies using Android TextToSpeech
- User speech can interrupt Agent speech (barge-in)
- Silent foreground notification while live voice is active
- Optional screen sharing so Gemini can see the current screen
- Accessibility-based non-sensitive form filling
- Opening installed apps by name
- Opening websites
- Safe visible-button clicking through Accessibility
- Notification access and quick replies where Android exposes a reply action

## GitHub upload

Do NOT upload this ZIP itself if you want GitHub Actions to build it.

Extract the ZIP and upload these items to the repository root:

- `.github/`
- `app/`
- `build.gradle`
- `gradle.properties`
- `settings.gradle`
- `README.md`

The repository root must directly contain `settings.gradle` and `app/`.

## Android setup

1. Install the APK built by GitHub Actions.
2. Open Agent.
3. Paste your own Gemini API key and press **SAVE GEMINI API KEY**.
4. Enable **Screen Control** in Android Accessibility settings if you want app opening/forms/buttons.
5. Enable **Share Screen** if you want the assistant to inspect the current screen.
6. Press **START LIVE VOICE** for background voice.

Never put a real API key into GitHub source files or commit history.
