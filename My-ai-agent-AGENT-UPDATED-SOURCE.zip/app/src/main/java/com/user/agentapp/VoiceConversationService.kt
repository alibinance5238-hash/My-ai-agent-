package com.user.agentapp

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import android.content.pm.ServiceInfo
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

/** Background voice loop. It listens only while Live Voice is enabled. */
class VoiceConversationService : Service(), RecognitionListener, TextToSpeech.OnInitListener {
    companion object {
        const val ACTION_START = "com.user.agentapp.START_VOICE"
        const val ACTION_STOP = "com.user.agentapp.STOP_VOICE"
        const val CHANNEL_ID = "agent_voice"
        const val NOTIFICATION_ID = 3001
        const val EXTRA_STATUS = "voice_status"
        var running = false
            private set
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var processing = false
    private var userIsSpeaking = false
    private var agentSpeaking = false
    private var audioManager: AudioManager? = null
    private var focusRequest: AudioFocusRequest? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        audioManager = getSystemService(AUDIO_SERVICE) as AudioManager
        tts = TextToSpeech(this, this)
        ServiceCompat.startForeground(
            this,
            NOTIFICATION_ID,
            buildNotification("Live Voice ON — Agent sun raha hai"),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopSelf()
            ACTION_START, null -> startVoice()
        }
        return START_STICKY
    }

    private fun startVoice() {
        if (running) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            sendStatus("Speech recognition available nahi hai.")
            stopSelf()
            return
        }
        running = true
        requestAudioFocus()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(this)
        startListening()
    }

    private fun startListening() {
        if (!running || processing) return
        try {
            recognizer?.cancel()
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ur-PK")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ur-PK")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 900)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 700)
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            }
            recognizer?.startListening(intent)
        } catch (e: Exception) {
            sendStatus("Mic start nahi hua: ${e.message ?: "unknown error"}")
        }
    }

    override fun onDestroy() {
        running = false
        processing = false
        recognizer?.cancel()
        recognizer?.destroy()
        recognizer = null
        tts?.stop()
        tts?.shutdown()
        tts = null
        agentSpeaking = false
        abandonAudioFocus()
        scope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onReadyForSpeech(params: Bundle?) {
        sendStatus("Sun raha hoon...")
    }

    override fun onBeginningOfSpeech() {
        userIsSpeaking = true
        tts?.stop()
        sendStatus("Aap bol rahe hain...")
    }

    override fun onRmsChanged(rmsdB: Float) {}
    override fun onBufferReceived(buffer: ByteArray?) {}
    override fun onEndOfSpeech() { userIsSpeaking = false }
    override fun onEvent(eventType: Int, params: Bundle?) {}

    override fun onPartialResults(partialResults: Bundle?) {
        val text = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            ?.firstOrNull().orEmpty().trim()
        if (text.isNotBlank()) {
            tts?.stop()
        }
    }

    override fun onResults(results: Bundle?) {
        userIsSpeaking = false
        val spoken = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            ?.firstOrNull().orEmpty().trim()
        if (spoken.isBlank() || !running) {
            if (running && !agentSpeaking) startListening()
            return
        }
        if (agentSpeaking) {
            // User interrupted the agent. Stop speech immediately and handle the new turn.
            tts?.stop()
            agentSpeaking = false
        }
        processSpeech(spoken)
    }

    override fun onError(error: Int) {
        if (!running || processing) return
        // Do not create a tight error loop that causes sounds or battery drain.
        sendStatus("Dobara sun raha hoon...")
        recognizer?.cancel()
        android.os.Handler(mainLooper).postDelayed({ startListening() }, 350)
    }

    private fun processSpeech(spoken: String) {
        processing = true
        recognizer?.cancel()
        sendStatus("Aap: $spoken")

        scope.launch {
            val screen = ScreenShareService.latestJpeg
            val rawReply = withContext(Dispatchers.IO) {
                GeminiClient.ask(this@VoiceConversationService, spoken, screen)
            }

            val actionResult = CommandExecutor.executeGeminiActions(this@VoiceConversationService, rawReply)
            val spokenReply = CommandExecutor.cleanReply(rawReply)
            val finalReply = if (actionResult.isNotBlank() && spokenReply == "Ho gaya.") actionResult else spokenReply

            sendStatus("Agent: $finalReply")
            speakThenListen(finalReply)
        }
    }

    private fun speakThenListen(text: String) {
        if (!ttsReady || text.isBlank()) {
            processing = false
            agentSpeaking = false
            startListening()
            return
        }

        tts?.stop()
        agentSpeaking = true
        val result = tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "agent_reply")
        if (result != TextToSpeech.SUCCESS) {
            processing = false
            agentSpeaking = false
            startListening()
            return
        }

        // Keep the recognizer active so the user can interrupt the spoken reply.
        processing = false
        startListening()
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        if (ttsReady) {
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    agentSpeaking = true
                }

                override fun onDone(utteranceId: String?) {
                    if (utteranceId == "agent_reply") {
                        agentSpeaking = false
                        processing = false
                        if (running && !userIsSpeaking) {
                            android.os.Handler(mainLooper).post { startListening() }
                        }
                    }
                }

                override fun onError(utteranceId: String?) {
                    if (utteranceId == "agent_reply") {
                        agentSpeaking = false
                        processing = false
                        if (running) android.os.Handler(mainLooper).post { startListening() }
                    }
                }
            })

            val result = tts?.setLanguage(Locale("ur", "PK")) ?: TextToSpeech.ERROR
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                // Roman Urdu can still be spoken by an English voice if Urdu TTS is unavailable.
                tts?.setLanguage(Locale.US)
            }
            tts?.setSpeechRate(0.95f)
        }
    }

    private fun requestAudioFocus() {
        val manager = audioManager ?: return
        if (Build.VERSION.SDK_INT >= 26) {
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANT)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
            focusRequest = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                .setAudioAttributes(attrs)
                .setAcceptsDelayedFocusGain(false)
                .build()
            manager.requestAudioFocus(focusRequest!!)
        } else {
            @Suppress("DEPRECATION")
            manager.requestAudioFocus(null, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
        }
    }

    private fun abandonAudioFocus() {
        val manager = audioManager ?: return
        if (Build.VERSION.SDK_INT >= 26) {
            focusRequest?.let { manager.abandonAudioFocusRequest(it) }
        } else {
            @Suppress("DEPRECATION")
            manager.abandonAudioFocus(null)
        }
    }

    private fun sendStatus(text: String) {
        val intent = Intent("com.user.agentapp.VOICE_STATUS").apply {
            setPackage(packageName)
            putExtra(EXTRA_STATUS, text)
        }
        sendBroadcast(intent)
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Agent live voice", NotificationManager.IMPORTANCE_LOW).apply {
                    setSound(null, null)
                    enableVibration(false)
                }
            )
        }
    }

    private fun buildNotification(text: String): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Agent")
            .setContentText(text)
            .setOngoing(true)
            .setSilent(true)
            .build()
}
