package com.user.agentapp

import android.content.Context
import android.content.Intent
import android.net.Uri

/** Opens installed apps, websites and performs safe screen actions requested by Gemini. */
object CommandExecutor {

    private val KNOWN_APPS = mapOf(
        "tiktok" to "com.zhiliaoapp.musically",
        "ebay" to "com.ebay.mobile",
        "youtube" to "com.google.android.youtube",
        "instagram" to "com.instagram.android",
        "facebook" to "com.facebook.katana",
        "whatsapp" to "com.whatsapp",
        "chrome" to "com.android.chrome",
        "google chrome" to "com.android.chrome"
    )

    private val KNOWN_WEBSITES = mapOf(
        "tiktok" to "https://www.tiktok.com",
        "ebay" to "https://www.ebay.com",
        "youtube" to "https://www.youtube.com",
        "instagram" to "https://www.instagram.com",
        "facebook" to "https://www.facebook.com",
        "whatsapp" to "https://web.whatsapp.com",
        "cj dropshipping" to "https://cjdropshipping.com",
        "google ads" to "https://ads.google.com"
    )

    fun tryOpenAppFromText(context: Context, text: String): String? {
        val lower = text.lowercase()
        val wantsOpen = listOf("kholo", "open", "khol do", "kholna", "chalao", "launch").any { lower.contains(it) }
        if (!wantsOpen) return null

        for ((name, pkg) in KNOWN_APPS) {
            if (lower.contains(name)) return openApp(context, name, pkg)
        }

        // Try matching any installed app label. This lets the user say "Calculator kholo"
        // without hard-coding every package name.
        val words = lower.split(Regex("\\s+"))
        val apps = context.packageManager.getInstalledApplications(0)
        for (app in apps) {
            val label = context.packageManager.getApplicationLabel(app).toString()
            val normalized = label.lowercase()
            if (normalized.length >= 3 && (lower.contains(normalized) || words.any { it.length >= 4 && normalized.contains(it) })) {
                val intent = context.packageManager.getLaunchIntentForPackage(app.packageName)
                if (intent != null) {
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(intent)
                    return "$label khol raha hoon."
                }
            }
        }
        return null
    }

    fun executeGeminiActions(context: Context, reply: String): String {
        val results = mutableListOf<String>()

        Regex("\\[ACTION:OPEN_APP:(.+?)]").findAll(reply).forEach { match ->
            val name = match.groupValues[1].trim()
            results += openNamedApp(context, name)
        }

        Regex("\\[ACTION:OPEN_URL:(https?://[^\\s\\]]+)]").findAll(reply).forEach { match ->
            val url = match.groupValues[1].trim()
            results += openUrl(context, url)
        }

        Regex("\\[ACTION:FILL:([^:]+):(.+?)]").findAll(reply).forEach { match ->
            val field = match.groupValues[1].trim()
            val value = match.groupValues[2].trim()
            val service = AgentAccessibilityService.runningInstance
            if (service == null) {
                results += "Screen Control ON nahi hai."
            } else {
                results += if (service.fillFieldByKeyword(field, value)) {
                    "$field wali field bhar di."
                } else {
                    "$field wali field nahi mili ya sensitive field thi."
                }
            }
        }

        Regex("\\[ACTION:CLICK:([^]]+)]").findAll(reply).forEach { match ->
            val text = match.groupValues[1].trim()
            val service = AgentAccessibilityService.runningInstance
            if (service == null) {
                results += "Screen Control ON nahi hai."
            } else {
                results += if (service.clickByText(text)) "$text par click kar diya." else "$text button nahi mila."
            }
        }

        return results.joinToString(" ")
    }

    fun cleanReply(reply: String): String {
        return reply
            .replace(Regex("\\[ACTION:OPEN_APP:.+?]"), "")
            .replace(Regex("\\[ACTION:OPEN_URL:https?://[^\\s\\]]+]"), "")
            .replace(Regex("\\[ACTION:FILL:[^]]+]"), "")
            .replace(Regex("\\[ACTION:CLICK:[^]]+]"), "")
            .trim()
            .ifBlank { "Ho gaya." }
    }

    private fun openNamedApp(context: Context, name: String): String {
        val lower = name.lowercase()
        val known = KNOWN_APPS.entries.firstOrNull { lower.contains(it.key) }
        if (known != null) return openApp(context, known.key, known.value)

        val apps = context.packageManager.getInstalledApplications(0)
        val app = apps.firstOrNull {
            context.packageManager.getApplicationLabel(it).toString().equals(name, ignoreCase = true)
        }
        return if (app != null) {
            val intent = context.packageManager.getLaunchIntentForPackage(app.packageName)
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
                "$name khol raha hoon."
            } else "$name launch nahi ho saka."
        } else {
            val site = KNOWN_WEBSITES.entries.firstOrNull { lower.contains(it.key) }
            if (site != null && openUrl(context, site.value)) "$name app nahi mili, website khol di." else "$name nahi mila."
        }
    }

    private fun openApp(context: Context, name: String, packageName: String): String {
        val launchIntent = context.packageManager.getLaunchIntentForPackage(packageName)
        return if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launchIntent)
            "$name khol raha hoon."
        } else {
            val url = KNOWN_WEBSITES[name]
            if (url != null && openUrl(context, url)) "$name app installed nahi hai, website khol di." else "$name nahi mila."
        }
    }

    private fun openUrl(context: Context, url: String): Boolean {
        return try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            true
        } catch (_: Exception) {
            false
        }
    }
}
