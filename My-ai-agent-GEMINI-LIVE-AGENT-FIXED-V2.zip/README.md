# My AI Agent — Gemini Live Agent Fixed

This build is configured for Gemini 3.8 Live (`gemini-3.8-live`) for low-latency voice interaction, with safe Android actions through Accessibility.

## Important fixes in this revision
- Corrected Gemini Live context-window compression JSON: `slidingWindow` is used by itself because `slidingWindow` and `triggerTokens` are mutually exclusive in the Live API.
- Live API errors now close the broken socket and trigger controlled reconnects instead of leaving the app showing "Live connected" while no voice works.
- Microphone startup is checked explicitly; the app reports if Android did not actually start recording.
- Audio is routed to the phone speaker in communication mode and playback uses a dedicated PCM queue.
- Gemini interruption events flush the playback queue so the user can interrupt the agent.
- Live function tools are non-blocking and return a `WHEN_IDLE` response policy so long actions do not unnecessarily freeze the conversation.
- Common open-app/open-website commands also have a local deterministic path in the normal/one-shot voice flow.
- Background app/website launching prefers the active Accessibility service when available.
- Typed Gemini requests use `gemini-3.8-flash` with `gemini-3.6-flash` fallback when the primary model is temporarily overloaded/unavailable.

## Setup
1. Enable **Screen Control** in Android Accessibility settings.
2. Grant microphone permission.
3. Create a Gemini API key in Google AI Studio and paste it into the app.
4. Save the key.
5. Tap **START BACKGROUND VOICE** and wait until the app says Live Voice is ON.
6. Say commands such as:
   - "TikTok kholo"
   - "eBay website kholo"
   - "Screen neeche scroll karo"
   - "Is field mein Ali likho"

## Safety
The agent intentionally refuses to type passwords, OTPs, PINs, CVV/card numbers, verification codes, or other authentication/payment secrets.
