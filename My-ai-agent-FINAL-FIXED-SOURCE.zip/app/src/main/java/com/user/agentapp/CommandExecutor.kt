package com.user.agentapp

import android.content.Context
import android.content.Intent
import android.net.Uri
import java.util.Locale

/** Executes deterministic device actions requested by voice or Gemini. */
object CommandExecutor {

    data class VoiceCommandResult(val message: String)

    private val KNOWN_APPS = mapOf(
        "tiktok" to "com.zhiliaoapp.musically",
        "ebay" to "com.ebay.mobile",
        "youtube" to "com.google.android.youtube",
        "instagram" to "com.instagram.android",
        "facebook" to "com.facebook.katana",
        "whatsapp" to "com.whatsapp",
        "chrome" to "com.android.chrome",
        "google chrome" to "com.android.chrome"
    )

    private val KNOWN_WEBSITES = mapOf(
        "tiktok" to "https://www.tiktok.com",
        "ebay" to "https://www.ebay.com",
        "youtube" to "https://www.youtube.com",
        "instagram" to "https://www.instagram.com",
        "facebook" to "https://www.facebook.com",
        "whatsapp" to "https://web.whatsapp.com",
        "cj dropshipping" to "https://cjdropshipping.com",
        "google ads" to "https://ads.google.com",
        "google" to "https://www.google.com"
    )

    /**
     * Handles commands that do not need Gemini at all. This is important for
     * background voice: common actions remain reliable even if the network is slow.
     */
    fun executeVoiceCommand(context: Context, text: String): VoiceCommandResult? {
        val lower = text.lowercase(Locale.ROOT).trim()

        // Stop live voice.
        if (listOf("voice band", "live voice band", "background voice band", "sunna band")
                .any { lower.contains(it) }) {
            return VoiceCommandResult("Live voice band kar raha hoon.").also {
                context.stopService(Intent(context, VoiceConversationService::class.java).setAction(VoiceConversationService.ACTION_STOP))
            }
        }

        val openWords = listOf("kholo", "khol do", "kholna", "open", "launch", "chalao")
        if (openWords.any { lower.contains(it) }) {
            for ((name, pkg) in KNOWN_APPS.entries.sortedByDescending { it.key.length }) {
                if (lower.contains(name)) {
                    return VoiceCommandResult(openApp(context, name, pkg))
                }
            }

            for ((name, url) in KNOWN_WEBSITES.entries.sortedByDescending { it.key.length }) {
                if (lower.contains(name)) {
                    return VoiceCommandResult(
                        if (openUrl(context, url)) "$name khol raha hoon." else "$name nahi khul saka."
                    )
                }
            }
        }

        // "yahan likho: Ali" / "is field mein Ali likho"
        if (lower.startsWith("yahan likho") || lower.contains("yahan likho:")) {
            val value = text.substringAfter(":", text.removePrefix("yahan likho").trim()).trim()
            if (value.isNotBlank()) {
                val service = AgentAccessibilityService.runningInstance
                val ok = service?.fillFocusedField(value) == true
                return VoiceCommandResult(if (ok) "Likh diya." else "Field nahi mili ya sensitive field thi.")
            }
        }

        // "name ki jagah Ali likho", "name wali field mein Ali likho"
        val keywordFillRegex = Regex(
            """(.+?)\s*(ki jagah|wali jagah|wali field|field mein)\s*likho[:\s]+(.+)""",
            RegexOption.IGNORE_CASE
        )
        val match = keywordFillRegex.find(text)
        if (match != null) {
            val keyword = match.groupValues[1].trim()
            val value = match.groupValues[3].trim()
            val service = AgentAccessibilityService.runningInstance
            val ok = service?.fillFieldByKeyword(keyword, value) == true
            return VoiceCommandResult(if (ok) "$keyword wali field bhar di." else "Woh field nahi mili ya sensitive thi.")
        }

        // "button par click karo" / "submit click karo"
        val clickRegex = Regex("""(?:click|tap)\s+(.+?)(?:\s+karo|\s+do)?$""", RegexOption.IGNORE_CASE)
        val clickMatch = clickRegex.find(text)
        if (clickMatch != null) {
            val label = clickMatch.groupValues[1].trim()
            val service = AgentAccessibilityService.runningInstance
            val ok = service?.clickByText(label) == true
            return VoiceCommandResult(if (ok) "$label par click kar diya." else "$label button nahi mila.")
        }

        return null
    }

    fun tryOpenAppFromText(context: Context, text: String): String? {
        val lower = text.lowercase(Locale.ROOT)
        val wantsOpen = listOf("kholo", "open", "khol do", "kholna", "chalao", "launch")
            .any { lower.contains(it) }
        if (!wantsOpen) return null

        for ((name, pkg) in KNOWN_APPS.entries.sortedByDescending { it.key.length }) {
            if (lower.contains(name)) return openApp(context, name, pkg)
        }

        return null
    }

    fun executeGeminiActions(context: Context, reply: String): String {
        val results = mutableListOf<String>()
        val normalized = reply.replace("```", "").replace("[ACTION:", "\n[ACTION:")

        Regex("\\[ACTION:OPEN_APP:(.+?)]", RegexOption.IGNORE_CASE).findAll(normalized).forEach { match ->
            results += openNamedApp(context, match.groupValues[1].trim())
        }

        Regex("\\[ACTION:OPEN_URL:(https?://[^\\s\\]]+)]", RegexOption.IGNORE_CASE).findAll(normalized).forEach { match ->
            results += if (openUrl(context, match.groupValues[1].trim())) "Website khol di." else "Website nahi khul saki."
        }

        Regex("\\[ACTION:FILL:([^:]+):(.+?)]", RegexOption.IGNORE_CASE).findAll(normalized).forEach { match ->
            val field = match.groupValues[1].trim()
            val value = match.groupValues[2].trim()
            val service = AgentAccessibilityService.runningInstance
            results += if (service == null) {
                "Screen Control ON nahi hai."
            } else if (service.fillFieldByKeyword(field, value)) {
                "$field wali field bhar di."
            } else {
                "$field wali field nahi mili ya sensitive field thi."
            }
        }

        Regex("\\[ACTION:CLICK:([^]]+)]", RegexOption.IGNORE_CASE).findAll(normalized).forEach { match ->
            val text = match.groupValues[1].trim()
            val service = AgentAccessibilityService.runningInstance
            results += if (service == null) {
                "Screen Control ON nahi hai."
            } else if (service.clickByText(text)) {
                "$text par click kar diya."
            } else {
                "$text button nahi mila."
            }
        }

        return results.joinToString(" ")
    }

    fun cleanReply(reply: String): String {
        return reply
            .replace(Regex("\\[ACTION:OPEN_APP:.+?]", RegexOption.IGNORE_CASE), "")
            .replace(Regex("\\[ACTION:OPEN_URL:https?://[^\\s\\]]+]", RegexOption.IGNORE_CASE), "")
            .replace(Regex("\\[ACTION:FILL:[^]]+]", RegexOption.IGNORE_CASE), "")
            .replace(Regex("\\[ACTION:CLICK:[^]]+]", RegexOption.IGNORE_CASE), "")
            .replace(Regex("```(?:text|plaintext)?", RegexOption.IGNORE_CASE), "")
            .replace("```", "")
            .trim()
            .ifBlank { "Ho gaya." }
    }

    private fun openNamedApp(context: Context, name: String): String {
        val lower = name.lowercase(Locale.ROOT)
        val known = KNOWN_APPS.entries.firstOrNull { lower.contains(it.key) }
        if (known != null) return openApp(context, known.key, known.value)

        val apps = context.packageManager.getInstalledApplications(0)
        val app = apps.firstOrNull {
            context.packageManager.getApplicationLabel(it).toString().equals(name, ignoreCase = true)
        }
        if (app != null) {
            val intent = context.packageManager.getLaunchIntentForPackage(app.packageName)
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
                return "$name khol raha hoon."
            }
        }

        val site = KNOWN_WEBSITES.entries.firstOrNull { lower.contains(it.key) }
        return if (site != null && openUrl(context, site.value)) {
            "$name app nahi mili, website khol di."
        } else {
            "$name nahi mila."
        }
    }

    private fun openApp(context: Context, name: String, packageName: String): String {
        val launchIntent = context.packageManager.getLaunchIntentForPackage(packageName)
        return if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launchIntent)
            "$name khol raha hoon."
        } else {
            val url = KNOWN_WEBSITES[name]
            if (url != null && openUrl(context, url)) {
                "$name app installed nahi hai, website khol di."
            } else {
                "$name nahi mila."
            }
        }
    }

    private fun openUrl(context: Context, url: String): Boolean {
        return try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                    or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            }
            context.startActivity(intent)
            true
        } catch (_: Exception) {
            false
        }
    }

    
}
